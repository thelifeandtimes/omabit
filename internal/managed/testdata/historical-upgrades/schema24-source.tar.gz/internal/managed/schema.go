package managed

// StateSchemaVersion is also queried from the built runner by release tooling.
// Schema24 fences project preparation journals and interrupted dispatch from older readers.
// Migration adds empty project tables while preserving legacy bodies and replay
// receipts. Opening the store does not create or adopt any runtime resources.
const StateSchemaVersion = 24
