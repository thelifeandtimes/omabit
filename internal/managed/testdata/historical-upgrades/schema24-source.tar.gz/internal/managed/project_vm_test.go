//go:build linux && amd64

package managed

import (
	"context"
	"encoding/json"
	"errors"
	"os"
	"os/exec"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
	"time"

	"git.thechristophgroup.org/thelifeandtimes/omabit/internal/projectnetwork"
	"git.thechristophgroup.org/thelifeandtimes/omabit/internal/runtimequalify"
)

// This explicit test-binary entry point is never enabled by the ordinary suite.
// It is packaged only in the no-NIC disposable QEMU appliance, after owner setup.
// It does not start an anchor or ship and retains every resource and database.
func TestProjectPreparationDisposableVM(t *testing.T) {
	if os.Getenv("OMABIT_TEST_PROJECT_VM") != "offline-project-preparation-v1" {
		t.Skip("requires the fresh offline qualification VM")
	}
	for name, want := range map[string]string{
		"/opt/omabit-lab/guest-marker": "offline-import-guest-v1\n",
		"/sys/class/dmi/id/sys_vendor": "QEMU\n",
		"/proc/1/comm":                 "systemd\n",
		"/etc/hostname":                "omabit-disposable-import\n",
	} {
		b, e := os.ReadFile(name)
		if e != nil || string(b) != want {
			t.Fatal("disposable guest admission refused", name)
		}
	}
	cmdline, e := os.ReadFile("/proc/cmdline")
	if e != nil || !strings.Contains(string(cmdline), "omabit.disposable-guest=offline-import-v1") {
		t.Fatal("guest boot marker missing")
	}
	if os.Geteuid() != 1000 || os.Getenv("HOME") != "/home/lab" || os.Getenv("XDG_RUNTIME_DIR") != "/run/user/1000" {
		t.Fatal("wrong disposable owner")
	}
	devices, e := os.ReadDir("/sys/class/net")
	if e != nil || len(devices) != 1 || devices[0].Name() != "lo" {
		t.Fatal("guest has an external network device")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 180*time.Second)
	defer cancel()
	const dir = "/home/lab/project-qualification-store"
	if e = os.Mkdir(dir, 0700); e != nil {
		t.Fatal("qualification store must be fresh", e)
	}
	report := map[string]any{"ok": false, "stage": "store", "ship_operations": false}
	defer func() {
		b, e := json.MarshalIndent(report, "", "  ")
		if e == nil {
			e = os.WriteFile("/home/lab/project-preparation.json", append(b, '\n'), 0600)
		}
		if e != nil {
			t.Error(e)
		}
	}()
	s, e := openStore(dir)
	if e != nil {
		t.Fatal(e)
	}
	defer func() {
		if s != nil {
			s.close()
		}
	}()
	reg, hit, e := s.registerProject("qualification", projectRequest(t, "register-vm", "vm", 18381))
	if e != nil || hit {
		t.Fatal(reg, hit, e)
	}
	p, e := loadProject(s.db, reg.ProjectID)
	if e != nil {
		t.Fatal(e)
	}
	digest, e := p.Plan.Digest()
	if e != nil {
		t.Fatal(e)
	}
	req := projectPrepareRequest{RequestID: "prepare-vm", ExpectedRevision: p.Revision, ReviewDigest: digest}
	op, hit, e := s.acceptProjectPreparation("qualification", p.ID, req)
	if e != nil || hit {
		t.Fatal(op, hit, e)
	}
	report["project"] = p
	report["operation_id"] = op.ID
	report["runner_id"] = s.runnerID
	selection := runtimequalify.ProjectPreparationSelection{RunnerID: s.runnerID, ProjectID: p.ID, OperationID: op.ID, Revision: p.Revision, Generation: 1, Plan: p.Plan}
	report["stage"] = "open-session"
	prepared, adapter, e := runtimequalify.OpenProjectPreparation(ctx, selection)
	if e != nil {
		t.Fatal(e)
	}
	report["prepared"] = prepared
	wrapped := &vmPreparationEngine{store: s, id: p.ID, engine: adapter}
	docker := func(args ...string) json.RawMessage {
		t.Helper()
		c := exec.CommandContext(ctx, "/usr/bin/docker", append([]string{"--config", filepath.Join("/home/lab/.local/share/urbit-runner/managed", "project-resources-"+p.ID, "docker-config"), "--host", "unix:///run/user/1000/urbit-docker.sock"}, args...)...)
		c.Env = []string{"HOME=/home/lab", "PATH=/usr/bin:/bin", "XDG_RUNTIME_DIR=/run/user/1000", "LC_ALL=C"}
		b, err := c.Output()
		if err != nil {
			t.Fatal("private read-only inspection failed", args[0], err)
		}
		return json.RawMessage(b)
	}
	volumesBefore := string(docker("volume", "ls", "--quiet"))
	report["volumes_before"] = strings.Fields(volumesBefore)
	report["stage"] = "execute"
	e = s.runProjectPreparation(ctx, p.ID, op.ID, prepared, wrapped)
	j, jerr := loadProjectJob(s.db, p.ID)
	report["journal"] = j
	report["calls"] = wrapped.calls
	receipt, recerr := loadOperation(s.db, op.ID)
	report["operation"] = receipt
	// Preserve exact-ID inspections even if the contract rejects normalization.
	if jerr == nil && j.Preparation != nil {
		if id := j.Preparation.Bridge.ID; id != "" {
			report["bridge_inspection"] = docker("network", "inspect", id)
		}
		if id := j.Preparation.Anchor.ID; id != "" {
			report["anchor_inspection"] = docker("container", "inspect", id)
		}
	}
	report["volumes_after"] = strings.Fields(string(docker("volume", "ls", "--quiet")))
	if e != nil || jerr != nil || recerr != nil {
		t.Fatal(e, jerr, recerr)
	}
	if !reflect.DeepEqual(report["volumes_before"], report["volumes_after"]) {
		t.Fatal("anchor generated an unrecorded persistent volume")
	}
	if j.Preparation == nil || j.Preparation.Sequence != 6 || receipt.Status != "succeeded" || len(wrapped.calls) != 4 {
		t.Fatal("incomplete resource preparation")
	}
	calls := len(wrapped.calls)
	if e = s.runProjectPreparation(ctx, p.ID, op.ID, prepared, wrapped); e == nil || len(wrapped.calls) != calls {
		t.Fatal("repeat worker dispatched")
	}
	if _, _, e = runtimequalify.OpenProjectPreparation(ctx, selection); e == nil {
		t.Fatal("existing workspace reused")
	}
	report["stage"] = "reopen"
	if e = s.close(); e != nil {
		t.Fatal(e)
	}
	s = nil
	s, e = openStore(dir)
	if e != nil {
		t.Fatal(e)
	}
	if e = s.reconcileInterrupted(); e != nil {
		t.Fatal(e)
	}
	replay, hit, e := s.acceptProjectPreparation("qualification", p.ID, req)
	if e != nil || !hit || !reflect.DeepEqual(replay, receipt) {
		t.Fatal("restart changed receipt", e)
	}
	after, e := loadProjectJob(s.db, p.ID)
	if e != nil || !reflect.DeepEqual(j, after) {
		t.Fatal("restart changed journal", e)
	}
	var count int
	if e = s.db.QueryRow("SELECT COUNT(*) FROM instances").Scan(&count); e != nil || count != 0 {
		t.Fatal("preparation created instances", e)
	}
	report["reopen_receipt_unchanged"] = true
	report["repeated_dispatch_refused"] = true
	report["instances"] = count
	report["stage"] = "complete"
	report["ok"] = true
}

type vmPreparationEngine struct {
	store  *store
	id     string
	engine projectnetwork.PreparationEngine
	calls  []string
}

func (e *vmPreparationEngine) VerifyEngine(ctx context.Context, id string) error {
	return e.engine.VerifyEngine(ctx, id)
}
func (e *vmPreparationEngine) check(kind string, c projectnetwork.Creation, phase string) error {
	j, err := loadProjectJob(e.store.db, e.id)
	if err != nil {
		return err
	}
	if j.Preparation == nil {
		return errors.New("no durable preparation")
	}
	expected := j.Preparation.Bridge
	if kind == "anchor" {
		expected = j.Preparation.Anchor
	}
	if expected != c || c.Phase != phase {
		return errors.New("resource effect preceded its journal commit")
	}
	e.calls = append(e.calls, phase+"-"+kind)
	return nil
}
func (e *vmPreparationEngine) Create(ctx context.Context, kind string, c projectnetwork.Creation, bridge string) (string, error) {
	if err := e.check(kind, c, "dispatched"); err != nil {
		return "", err
	}
	return e.engine.Create(ctx, kind, c, bridge)
}
func (e *vmPreparationEngine) Inspect(ctx context.Context, kind string, c projectnetwork.Creation, bridge string) (projectnetwork.ResourceIdentity, error) {
	if err := e.check(kind, c, "created"); err != nil {
		return projectnetwork.ResourceIdentity{}, err
	}
	return e.engine.Inspect(ctx, kind, c, bridge)
}
