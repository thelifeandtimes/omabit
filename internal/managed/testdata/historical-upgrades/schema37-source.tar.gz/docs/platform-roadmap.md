# Omabit platform roadmap

Recorded 2026-10-21. Product direction from the user; the experiments below are
proposed delivery steps, not implemented contracts or live-operation approvals.
Source baseline: Omabit v0.2.0, commit `b233128`.

## Product anchor and repository ownership

**“Multiplayer apps without a subscription.”** This is the user's anchor phrase,
attributed by the user to DHH. Make the everyday experience demonstrate it:
connect your identity once, open an application, and collaborate using state on
your own ship. Hosting, hardware and optional services still have costs.

The three pillars are:

1. Run ships reliably and let independent operators manage a shared fleet.
2. Discover, install, use and develop Omarchy interfaces for Urbit applications,
   including links to web/PWA and native clients.
3. Approve an application's connection to an already authenticated ship instead
   of entering its URL and `+code` again for each plugin.

`thelifeandtimes/omabit` is the runner/collector/Omarchy integration repository.
`thelifeandtimes/tend` is independent. The retired Omabit/Tend monorepo, its
`apps/urbit-host` pilot and its layout-migration plan are historical context, not
the codebase to extend. Theme, DMs and Omachan likewise remain independently
installable. This roadmap does not require creating a new messenger client.

Theme and DMs are the first shared-authentication integration pair. Tend remains
the full multiplayer application proof. Talon and Lattice are reference clients
and discovery targets; learn from their patterns without assuming their security
or licensing choices can be copied wholesale.

## What already exists

| Area | Evidence in the current source | Remaining distinction |
| --- | --- | --- |
| Fleet management | Runner identities, operator/observer grants, revisions and durable operations; several collectors may enroll the same runner | Concurrent operators must not overwrite each other's changes or share credentials implicitly |
| Imports | `internal/managed/import_preview.go` derives the identity-based child; `docs/pier-storage.md` defines the exclusive parent mount | The screenshot reports a combined tree rejection; its actual cause is still unknown |
| Ship authentication | `docs/ship-sessions.md`; collector enrollment, login, status, scry, watch, logout and Secret Service/file adapters | Owner cookies are not app capabilities; generic application mutation transport is not supplied by that documented checkpoint |
| Hosted ships | Collector ship enrollment is independent of runner/SSH enrollment | Desktop onboarding and application approval still need a coherent flow |
| Desk inventory | Documented successful `hood /kiln/pikes` scry and `/kiln/updates` watch | Inventory needs normalization, freshness and separate Grubbery app/permit probes |
| Fake networking | Current storage docs describe container-local Ames; project directories exist | A shared directory label does not establish a communicating project network |
| Ethereum testnet | Storage docs explicitly call it a stub | Network identity, chain configuration and boot/runtime behavior need an explicit supported contract |
| Application Connections | README identifies the UI as Coming Soon | Target: separate ordinary Eyre sessions handed to plugins, with direct plugin-to-ship data flow |

## Execution discipline

One bounded change and its acceptance evidence at a time. Use a topic branch and
isolated worktree for active implementation; keep installed plugin files and
running services separate. Backend changes enter a new minor/major release line
(the next minor after 0.2.0 would be 0.3.0); this document does not publish one.
Preserve the [development policy](development-policy.md) and
[upgrade contract](upgrade-policy.md).

Completion of this roadmap is the active goal. Current experiments must follow
[the user's isolation constraints](experiment-isolation.md): preserve managed
`~lismyl-lismyl`, exclude tmux ships and `~/temp-ur`, and use separate experimental
plugin identities, desktop environments, state and credentials.

Each step ends with: the behavior demonstrated, exact source/artifact identity,
automated versus live evidence, limitations, and the next small experiment.
Read-only inspection, package installation, desk installation, application access
and starting a real identity are distinct operations. Approval must describe the
actual changes. No silent retry of an uncertain mutation.

The user has withdrawn the reported import source from testing: it is now running
as a standalone Urbit in `urbit-prod` on sourcebox. Do not inspect, stop, copy,
move, import or otherwise operate on that ship for this work. Use synthetic
fixtures and later explicitly designated disposable ships. Manual testing of the
reported source waits for renewed instructions and confirmation it is stopped.

## Step 1 — import reliability

First slice: replace the ambiguous tree rejection with a quoted relative entry
and the failed check. Preserve ownership, private state, link, mount and file-type
restrictions. Do not suggest recursive chmod/chown or lock deletion as a fix.
See [the diagnostic change](diagnostics/2026-10-21-import-diagnostics.md).
The [partial-copy preservation run](diagnostics/2026-10-22-import-interruption.md)
and [runner/CLI restoration checkpoint](diagnostics/2026-10-22-import-restore-integration.md)
record the earlier interruption and source integration checkpoints.
The [real restoration/re-import run](diagnostics/2026-10-22-import-restore-runtime.md)
now passes. [Guided restoration UI](diagnostics/2026-10-22-import-restore-ui.md)
also passes actual offscreen QML with inert dispatch. The [UI-to-VM trial](diagnostics/2026-10-22-import-restore-ui-runtime.md)
now passes actual collector/runner dispatch, preserved trees, retained receipts,
replay/re-import and explicit Start/Stop. Other failure modes and native desktop
integration remain open.

Next slices, separately:

- Verify a synthetic import retains `<instance-name>/<patp-without-tilde>` and
  mounts only the instance parent. Cover arbitrary source names, collisions,
  an existing legacy `pier` child, custom roots, and a comet with known identity.
- Distinguish newly mined comets (identity initially unknown) from imported
  comets. Decide a stopped, identity-verified rename policy before requiring a
  new comet's provisional `pier` child to become its name; never rename a live
  registered pier as a cosmetic fix.
- Exercise same-filesystem rename and cross-filesystem copy with interruptions,
  full disks, replaced sources, restart/retry and retained enrollment recovery.
- Run the guided UI on a disposable stopped pier. Check preview, progress,
  failure recovery, explicit Start and the resumed identity. Only then schedule
  review of a valuable pier under [protected ships](protected-ships.md).

Exit: actionable refusal, preserved source on failed preview, the required mount
layout, and demonstrated recovery without duplicate starts or lost pier data.

## Step 2 — CLI and operational skills

Inventory the actual commands first. Ship a concise operator `SKILL.md` with
links to task-specific references, separately from contributor instructions.
Agent entry points should progressively disclose:

1. Short help: what can be observed and the available command families.
2. Read-only status/capability discovery: version, runner/ship identity, authority,
   freshness and supported operations.
3. Command help/examples: required inputs, effect, prerequisites and secret input
   handling. Never invent a command in a skill that the shipped CLI lacks.
4. Machine-readable errors and next actions: unsupported capability, expired
   session, revision conflict, uncertain operation, and the operation receipt.
5. Detailed troubleshooting only on request, with redacted output.

Acceptance tasks: identify the intended runner, distinguish unreachable from
stopped, inspect an import rejection, monitor an asynchronous operation, and
recover from a stale revision. Exercise both readable output and structured output
using the built CLI, with simple scripted callers and human walkthroughs. Skills
describe authority limits; they are not enforcement against an unrestricted agent.

## Step 3 — project fake networks

Design a project identifier independent of filesystem labels, ship `@p`, and
instance IDs. Start with one runner, two disposable fake galaxies and one project.
Inspect the pinned Vere/Ames behavior before selecting bridge versus shared
namespace transport. Check administrative loopback exposure as well as Ames. The
[pinned-runtime source notes](project-fake-networks.md) record why a bridge alone
is insufficient and define the first private namespace experiment.

Acceptance ladder:

1. Bidirectional authenticated application messages between two fake ships.
2. Restart one ship and recover subscriptions/state without recreating its pier.
3. Run the same fake identities in a second project and prove no cross-project
   traffic, endpoint/cookie confusion, or administrative access.
4. Prove fakes cannot accidentally participate in the real network.
5. Add a two-runner project only after same-host behavior and trust boundaries
   are demonstrated. SSH fleet access alone is not a ship-network transport.

Checkpoint 2026-10-22: [the private Docker transport test passes](diagnostics/2026-10-22-docker-peer-recovery.md).
Rung 1 is demonstrated. Clean process/container replacement also preserves the
pier, namespace and original Eyre sessions, with messages working afterward.
Rung 2 remains open for persistent application state and subscriptions/client
reconnect; rung 3 and runner integration are still pending. No production rollout
or complete networking-feature qualification is implied.

Subsequent checkpoint: [Docker state/subscription recovery](diagnostics/2026-10-22-application-state-docker.md)
passes rung 2, and [two simultaneous duplicate-identity projects](diagnostics/2026-10-22-docker-project-isolation.md)
pass the isolated state/session portion of rung 3. These later records supersede
the pending status above. Published endpoint/administrative exposure and anchor
lifecycle still require their separate fixture before runner integration.

Record the trust of all ships sharing a namespace. Do not claim a shared
development namespace isolates hostile applications from one another.

[The ordinary-bridge endpoint fixture passed](diagnostics/2026-10-23-endpoint-publication.md)
with exact loopback mappings and coordinated recovery after namespace replacement.
This closes the HTTP-fixture publication/lifecycle experiment, not the actual
Urbit publication or durable runner project gates. The
[project contract draft](project-network-contract.md) records the remaining ownership,
reconciliation and upgrade requirements.

## Step 4 — shared authentication, direct application connections

Omabit assists with authentication and connection management. Each plugin then
talks **directly to Eyre** using its own session and transport. Omabit/collector
must not become the data provider, proxy or permanent dependency for plugin
scries, pokes, watches or reconnects. A plugin remains fully usable without
Omabit, including on a hosted Tlon ship: URL + `+code` login is a first-class
standalone path, not an emergency mode requiring Omabit binaries.

Use **Theme and DMs** as the first pair. They use agents in the standard `%groups`
stack (Theme: `%settings`; DMs: `%chat`, `%contacts`, `%activity`). Probe actual
backend readiness; bare or customized ships may differ. Tend is not part of the
first shared-authentication checkpoint.

The assisted flow is: select a saved ship, see the requesting plugin and profile,
approve, create a **new** ordinary Eyre session, and hand it privately to that
plugin's credential adapter. Separate sessions are required even when two plugins
use the same desk. Do not copy the collector's cookie to all plugins. Retain the
existing standalone login and plugin-owned storage/transport lifecycle.

Current Eyre sessions are not restricted to desks or paths. The first release
does not add inter-desk permission enforcement or an authorization proxy. Separate
sessions provide independent lifecycle/revocation, not capability isolation.
The user's 407k / Gall 2026 work is a future integration point, not an initial
dependency. Lattice's scoped keys remain useful research rather than a prerequisite.

Specify only the boundaries needed for this handoff:

- Binding to plugin ID, profile, connection ID, canonical origin and verified ship
  identity; repeated fake `~zod` identities must remain distinct connections.
- Explicit approval, private delivery, durable acceptance/cleanup, expiry and
  cancellation. Cookies and transient codes stay out of QML, argv, URLs and logs.
- Plugin-owned requests and reconnects after the auth helper exits. No automatic
  fallback to a collector proxy when direct data access fails.
- Logout of one exact plugin session; distinguish local removal, confirmed remote
  revocation and offline cleanup pending. Do not log out all ship sessions.
- Profile changes stop old watchers before activating another account; late
  responses cannot overwrite the new profile's state or credentials.

The next checkpoint is a small authentication experiment: one saved login creates
two distinct sessions; both clients read directly after the authentication client
closes; revoking one leaves the other and the original login usable. Test malformed
responses, wrong identity/origin, missing thread support, and session reuse. This
starts with synthetic HTTP fixtures; real ship compatibility requires a separately
authorized disposable target. See [the checkpoint](application-auth-checkpoint.md).

Then wire the handoff into Theme and DMs, testing assisted and standalone login,
process restart, keyring lock, session expiry, profile switching and operation
with Omabit stopped or absent. Extract shared client code only after both work.
Runner management permission never implicitly enrolls an application session or
shares one operator's session with every fleet operator.

## Step 5 — plugin-owned setup and compatibility, with Omart discovery

Omabit is **not an app store**. Its scope is connected-ship/software observations,
connection status and useful links. Do not build a catalog browsing, publishing,
ranking or marketplace system into it. If work starts to drift toward that scope,
stop and rethink whether it belongs in **Omart**, the existing alpha Urbit-based
Omarchy plugin marketplace. Consult `ahlmark/omart-desk` before designing
discovery infrastructure; do not create a parallel catalog as incidental work.

The default developer pattern belongs inside every standalone plugin:

1. Authenticate, through Omabit or directly using URL + `+code`.
2. Probe the required Clay desk/Gall agents or Grubbery app and permissions.
3. If absent, show an **Install backend** button naming the target ship, exact
   desk/app and publisher. Use the supported install mechanism after approval.
4. Observe installation, boot/readiness and Grubbery permits separately; show
   progress, refusal, retry or an incompatibility explanation.
5. Open the application using its own direct transport once compatible and ready.

This must work with no Omabit installation. A ship being unreachable is not proof
that its backend is missing. Installation cannot silently change an existing
publisher or grant unrelated permissions. Use Tend as a later missing-backend
demonstration; Omart already has a useful missing-`%pals` installation pattern.

Keep dependencies/source links and OS authorization visible when installing
desktop software. Shared conventions should describe backend identity/publisher,
readiness probes, protocol versions, supported client/backend combinations,
immutable artifact identity and update channels. Start with plugin-local metadata;
do not turn a compatibility descriptor into an Omabit catalog schema.

Track partial installation and compatibility explicitly. A desktop install and
ship update are not one atomic transaction. Test both update orders, old/new
client/backend pairs, offline/restart halfway through installation and backend
permission refusal. Preserve a last-known compatible desktop artifact without
promising to reverse ship migrations. Desk OTA must not silently execute new
desktop code outside the selected desktop update/consent policy.

Distribution experiments remain separate: native GitHub installation first,
optional desk-served artifacts second, optional Urgit Git remotes later.
[Urgit documents Git hosting and peer collaboration](https://github.com/yapishu/urgit);
it is not a mandatory dependency. Verify installer support and source provenance
before advertising ship-URL installation commands. Third-party plugin authors must
be able to maintain compatibility metadata independently of backend publishers.

## Step 6 — private Ethereum devnets and developer profiles

The initial happy path is a **private local Ethereum development chain**. Public
Goerli-style testnets are outside initial scope. Pin the chain configuration,
chain ID, Azimuth deployment/contracts, local RPC endpoint, disposable identities,
bootstrap pill and supported Vere options. An alternate RPC URL alone is not a
complete development network; qualify the pinned kernel/runtime and chain together.

Start with two disposable identities on one runner. Prove messaging, restart,
project isolation, wrong-chain rejection and absence of livenet key/port reuse.
Keep fake, private-chain and livenet classifications distinct in storage,
connection selection, UI and operation receipts. Multi-host work follows later.

The developer kit must also define **stable/dev/edge plugin collections**:

- A named profile selects a coherent set of plugin versions/channels and ship
  connections. Distinguish the selected collection from versions actually loaded.
- Keep state, caches, session keys and selected endpoints separate per profile.
  Never silently point a dev plugin at a production ship or copy owner sessions
  across profiles. Profile creation does not create/reset a pier or chain.
- Switch deliberately: stop the old helpers/watchers, activate the collection,
  verify readiness and recover the last working desktop collection on failure.
  Old in-flight results must not mutate the new profile. Returning to stable
  must not imply downgrading a runner database or reversing ship state.
- Test stable → dev → stable and stable → edge → stable with different fake
  endpoints, concurrent stale completions and independent authentication.
- Reuse lessons from [Omabit's existing desktop profiles](desktop-development.md),
  while proving collection-wide behavior against the actual Omarchy loader.
  Existing Omabit-only profiles do not yet establish whole-plugin-set switching.

Provide developer skills and a small working sample covering native design tokens,
keyboard/focus/accessibility, loading/stale/error states, direct Eyre transports,
assisted and standalone authentication, plugin-owned backend installation from a
named publisher, compatibility/reconnect/idempotency, and fake/private-chain
development commands. Include the profile workflow in the sample and skills.
Consult the current Omarchy plugin API and test on two independent ships.

## Core v1.0 release gates

- Import/layout and recovery acceptance, including an explicitly authorized
  manual UI pass; no duplicate real-identity starts.
- Understandable CLI discovery/errors and verified operational/developer skills.
- Demonstrated project fake networking and separately qualified private Ethereum devnet
  networking, with isolation and restart evidence.
- Independent multi-collector operation, stale revision handling, revocation and
  compatibility across the supported runner/collector/UI upgrade window.
- Theme/DMs separate-session handoff, direct data traffic with Omabit stopped,
  standalone hosted-ship login and independent logout. Desk isolation is deferred.
- Plugin-owned missing-backend installation and compatibility/update demonstration,
  with marketplace discovery kept in Omart.
- Stable/dev/edge collection switching with isolated credentials and state.
- Tests on the supported rootless Omarchy host; non-destructive upgrades,
  interruption recovery, diagnostics and documented limitations.

Wallet delivery, a universal app store, automatic failover, and adopting Urgit on
every ship are outside these gates. Retain wallet/key-storage research as part of
the connection architecture so future choices are informed rather than accidental.

## Reference snapshots consulted

These are local source observations, not independent release qualification:

- Omabit `b233128`: `docs/architecture.md`, `docs/ship-sessions.md`, storage docs,
  `internal/managed/import_preview.go`, `internal/pierstore/external_linux.go`.
- Tend `bd99c33`: `docs/TEND_SECURITY.md`, `docs/TEND_COMPATIBILITY.md` and
  `docs/TEND_REPOSITORY_MIGRATION.md` (independent repository and protocol gates).
- Talon `7cbaa15`: `core/.../urbit/UrbitSession.kt`, `UrbitChannel.kt`,
  `composeApp/.../DesktopSessionStore.kt`, `docs/grubbery-apps.md` (session/channel
  ownership, backend availability and installation UX).
- Lattice `5d90b16`: `code/lib/lattice-keys.hoon`, `code/nex/lattice/app.hoon`,
  `docs/releasing.md` (route scopes, revocation and separate update mechanisms).
- Theme `1719e9f`: `client/support.py`, `client/eyre.py` and README (Secret Service,
  multi-ship settings integration and explicit authentication-required state).
- DMs `cf236fd`: `session_store.py`, `bridge.py`, `browser_session.py` (origin-bound
  keyring sessions and private browser handoff).
- Omachan: uncommitted local source, `plugin/bridge.py` and README (memory-only
  session and staged backend onboarding); no commit-backed baseline yet.

## Immediate checkpoint after the 2026-10-21 corrections

Step 4's independent-session primitive and fixture tests are now implemented as
an internal experiment, before a shared SDK or approval UI. See the
[checkpoint evidence and next gate](application-auth-checkpoint.md). The source import diagnostic patch remains retained and tested;
its live acceptance waits for a designated disposable target. CLI, networking and
profile work remain separate checkpoints, not prerequisites for this auth experiment.
