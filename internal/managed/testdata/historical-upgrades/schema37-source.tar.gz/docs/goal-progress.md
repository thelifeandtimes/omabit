# Active platform goal

Complete the [platform roadmap](platform-roadmap.md) through staged acceptance
gates. Goal set by the user on 2026-10-21; not complete. Do not turn progress on one
gate into a release-wide completion claim.

The latest user constraints are in [experiment isolation](experiment-isolation.md)
and take precedence over historical deployment/reset permissions. In particular,
preserve managed `~lismyl-lismyl`, exclude tmux ships and `~/temp-ur`, and keep
experimental plugins separate from currently installed ones.

## Latest checkpoint — 2026-10-23

- VM29/schema37 now independently passes direct-client application/subscription recovery and healthy/stopped/restarted anchor review ([M159](diagnostics/2026-10-23-anchor-review-runtime.md)). Original disks, journals and final pier states are retained; the offline VM is stopped. This is diagnostic anchor review, not coordinated repair.

- Active source uses unreleased schema37 for current-context lifecycle. Focused
  store/queue/upgrade checks and full managed race972.505s pass
  ([M131](diagnostics/2026-10-23-current-context-lifecycle-store.md)).
  The earlier schema36 full regression passed in814.392s
  ([M127](diagnostics/2026-10-23-member-context-readiness-store.md)).
- Earlier schema35 repeated member replacements through generations3/4,
  migration/replay and the full managed race suite pass ([M113 evidence](diagnostics/2026-10-23-member-repeated-resume-store.md)).
- VM26/schema37 remains the fully queued final-Stop reference: queued sender
  lifecycle after peer changes, twelve remote writes and three subscription
  recovery cycles pass with original sessions and exact receiver continuity
  ([M137](diagnostics/2026-10-23-current-context-lifecycle-runtime.md)).
- Later read-only anchor review passes pure and concrete source gates
  ([M135](diagnostics/2026-10-23-anchor-recovery-review-model.md),
  [M136](diagnostics/2026-10-23-anchor-recovery-review-adapter.md)). These changes
  and M134 direct published transport are not included in frozen VM26.
- VM27/schema37 failed at sender replacement readiness before the anchor fault
  ([M143](diagnostics/2026-10-23-anchor-review-trial27.md)). Five direct-client phases
  and three replacements were recorded; originals and clean final piers are retained.
  Timing remains a hypothesis; the fixture diagnostics/audit placement pass source checks ([M144](diagnostics/2026-10-23-readiness-timing-fixture.md)).
- VM28 completes direct-client twelve-write/three-cycle recovery and readiness, then fails restarted-anchor inspection on retained historical FinishedAt plus a secondary fixture reopen panic ([M151](diagnostics/2026-10-23-anchor-review-trial28.md)). Original disks and both final piers are independently retained. Recovery-specific timestamp/fixture corrections are under regression; full runtime qualification remains open.
- Pure coordinated drain now passes full race13.805s/vet ([M139](diagnostics/2026-10-23-anchor-drain-model.md)); the concrete adapter also passes57 inert race cases ([M140](diagnostics/2026-10-23-anchor-drain-adapter.md)). Drain persistence, namespace succession and coordinated runtime remain pending.
- Explicit namespace succession passes its pure race/vet gate ([M141](diagnostics/2026-10-23-anchor-namespace-model.md)); its separate Docker adapter passes22 inert race cases ([M142](diagnostics/2026-10-23-anchor-namespace-adapter.md)). Coordinated retirement/replacement and persistence remain next.
- Coordinated retirement passes pure and concrete source gates ([M146](diagnostics/2026-10-23-anchor-retirement-model.md), [M147](diagnostics/2026-10-23-anchor-retirement-adapter.md)). Same-pier successor contracts and replacement are next; runtime and persistence remain pending.
- Explicit successor member contracts pass pure/concrete source checks without changing ordinary digests ([M148](diagnostics/2026-10-23-recovery-member-contract.md)); serial replacement execution is next.
- Pure serial replacement passes race/vet with uncertainty and peer continuity checks ([M149](diagnostics/2026-10-23-anchor-replacement-model.md)); concrete adapter tests are running. Running still does not imply fresh readiness or recovery completion.
- Concrete successor replacement passes inert race/vet ([M150](diagnostics/2026-10-23-anchor-replacement-adapter.md)). Fresh recovery readiness, causal history and persistence are next; the runtime recovery gate remains open.
- Recovery-specific historical timestamp handling and failed-review cleanup now pass exact VM28 regression, full pure race and related adapter race ([M152](diagnostics/2026-10-23-anchor-history-fix.md)). A fresh full VM rerun is next.
- Corrected appliance29/schema37 preparation ([M153](diagnostics/2026-10-23-anchor-history-rerun-preparation.md)) is now followed by the verified M159 runtime pass.
- Complete successor identity/readiness passes pure race/vet ([M154](diagnostics/2026-10-23-anchor-recovery-readiness-model.md)); concrete adapter checks are running.
- Complete successor readiness also passes its concrete observation-only adapter gate ([M155](diagnostics/2026-10-23-anchor-recovery-readiness-adapter.md)). Later causal history, persistence and coordinated runtime remain.
- Ordinary replacements after one complete recovery pass pure history/prefix checks ([M156](diagnostics/2026-10-23-recovered-member-generations.md)). Multiple recovery boundaries and concrete/persistent integration remain.
- Two recovery boundaries with ordinary replacements between/after them now pass pure history tests and existing adapter regressions ([M157](diagnostics/2026-10-23-recovery-epochs.md)). Concrete later contracts/readers and persistence remain next.
- Ordinary post-recovery creation contracts pass pure/concrete and legacy-format checks ([M158](diagnostics/2026-10-23-recovered-resume-contract.md)); generalized concrete readers and durable coordination remain.
- Concrete current-history readers pass recovery-only and mixed-creator source gates ([M160](diagnostics/2026-10-23-recovery-history-reader.md)); second concrete recovery and global historical-ID checks throughout its phases are next.
- Second coordinated recovery now passes concrete fixture gates, including stopped/restarted anchors, mixed creators and historical-ID guards at every phase ([M161](diagnostics/2026-10-23-second-recovery-adapters.md)); ordinary post-recovery lifecycle and persistence remain next.
- After those gates: coordinated anchor recovery, runner project public
  capabilities/CLI/UI, then remaining roadmap acceptance. The entries below retain
  earlier evidence; their older pending statements are historical.

| Area | Evidence / remaining work |
| --- | --- |
| Import diagnostics | Source diagnostics and [nine-case guided layout/runtime fixtures](diagnostics/2026-10-22-import-layout.md) passed; [actual guided UI and private VM boundary](diagnostics/2026-10-22-import-ui.md) passed; [offline installer/engine/runtime-version gate](diagnostics/2026-10-22-import-guest.md) passed; [real same-filesystem import/Start/Stop](diagnostics/2026-10-22-import-runtime.md) passed; [real cross-filesystem import/Start/Stop](diagnostics/2026-10-22-import-copy.md) passed; [partial-copy preservation](diagnostics/2026-10-22-import-interruption.md) passed; [runner/CLI source restoration](diagnostics/2026-10-22-import-restore-integration.md) passes source tests; [real restoration and re-import](diagnostics/2026-10-22-import-restore-runtime.md) and [guided UI fixtures](diagnostics/2026-10-22-import-restore-ui.md) passed; [actual UI-to-VM restoration](diagnostics/2026-10-22-import-restore-ui-runtime.md) passed; additional failure modes and native desktop integration remain |
| CLI and operational/developer skills | [Initial operator skill/offline help](diagnostics/2026-10-22-operator-entry.md) passed; [offline task families](diagnostics/2026-10-22-task-help.md) passed; [five scripted CLI tasks](diagnostics/2026-10-22-operator-walkthrough.md) passed; [initial plugin-developer guidance](diagnostics/2026-10-22-developer-skill.md) added and validated; [lost-reply reconciliation](diagnostics/2026-10-22-cli-lost-reply.md) and [structured error guidance](diagnostics/2026-10-22-cli-recovery-guidance.md) passed; import-recovery walkthrough expansion, other runtime next actions, skill distribution and developer acceptance remain |
| Fake project networking | [Pinned-runtime source notes](project-fake-networks.md) recorded; [Docker peer messaging and session recovery passed](diagnostics/2026-10-22-docker-peer-recovery.md); [Docker application state/subscription recovery passed](diagnostics/2026-10-22-application-state-docker.md); [duplicate-project isolation passed](diagnostics/2026-10-22-docker-project-isolation.md); [HTTP publication/anchor fixture passed](diagnostics/2026-10-23-endpoint-publication.md); [actual published Eyre state/subscription recovery passed](diagnostics/2026-10-23-published-state.md); [published duplicate-project isolation passed](diagnostics/2026-10-23-published-project-isolation.md); [actual-ship anchor state/subscription recovery passed](diagnostics/2026-10-23-anchor-state-recovery.md); runner integration remains |
| Independent sessions | Synthetic and [fresh-fake runtime](diagnostics/2026-10-21-isolated-auth.md) gates passed |
| Theme/DMs integration | [Private receiver, real keyring, direct read/SSE, independent logout and standalone helper gates passed](diagnostics/2026-10-21-plugin-handoff.md); [durable issuer fixture gate](diagnostics/2026-10-21-durable-issuer.md) passed; [verified launcher and real-pair recovery gate](diagnostics/2026-10-21-receiver-recovery.md) passed; [installed declarations/CLI and offscreen approval panel](diagnostics/2026-10-21-approval-flow.md) passed; [real CLI/panel/receiver and running-consumer gate](diagnostics/2026-10-21-public-auth-flow.md) passed; [completed archival and replay checkpoint](diagnostics/2026-10-22-application-history.md) passed; [three stale-stream regressions fixed](diagnostics/2026-10-22-dms-stream-generation.md); [actual writes/reconnect passed](diagnostics/2026-10-22-plugin-transport-native.md); [strict acknowledgement validation also passed](diagnostics/2026-10-22-plugin-receipts-native.md); retained-helper pruning, hosted compatibility and full profile gates remain |
| Backend installation/compatibility | Planned inside standalone plugins; catalog discovery stays in Omart |
| Private Ethereum chain | [Local-chain source constraints](private-chain-research.md) recorded; no runtime qualification or public-testnet work |
| Stable/dev/edge collections | Planned; current per-plugin credential names and desktop side effects need explicit isolation |
| Wallet/key storage | [Research notes](platform-security-notes.md) retained; implementation out of scope |

## Current development locations

- Omabit: `/home/thelifeandtimes/repos/omabit-platform-overhaul`, branch
  `codex/platform-overhaul-plan`, base `b233128`; changes uncommitted.
- Theme: `/home/thelifeandtimes/repos/omarchy-urbit-theme-auth`, branch
  `codex/omabit-auth`, base `1719e9f`; private receiver/profile and transport changes uncommitted.
- DMs: `/home/thelifeandtimes/repos/omarchy-urbit-dms-auth`, branch
  `codex/omabit-auth`, base `cf236fd`; private receiver/profile and transport changes uncommitted.

The normal checkouts and installed plugins have not been edited. The retired
Omabit/Tend monorepo in the chat's original directory is not the source to extend.
No release, installation or live-fleet upgrade has been made.

## Current work

The user resumed the full goal on 2026-10-22 and requested continued work without
stopping at each checkpoint. Persistent application-state and subscription recovery now pass in fresh native
and Docker fakes. Duplicate-identity project isolation now passes as well. The ordinary-bridge HTTP publication/anchor fixture now passes. Current work is
runner project integration; the combined published duplicate-project and actual-ship anchor recovery gates now pass.
Published Eyre application/subscription recovery has passed. [Real runner login
across same-pier restart](diagnostics/2026-10-23-login-restart.md) also passes, with
its original disks and independently verified receipts retained.
[Durable project reservations](diagnostics/2026-10-23-project-store.md) pass
source/migration checks. [Project runtime assessments](diagnostics/2026-10-23-project-observation.md)
now distinguish stopped members, unavailable resources and changed namespaces in
source tests. [Schema24 preparation journals](diagnostics/2026-10-23-project-journal.md)
retain each resource intent and returned ID before further work, with source and
original-reader migration checks passing. [Private controller/SQLite wiring](diagnostics/2026-10-23-project-dispatch.md) passes
inert-engine race tests. [Private Docker adapter and fresh session setup](diagnostics/2026-10-23-project-adapter.md)
pass inert-engine tests. [Private server admission/fencing](diagnostics/2026-10-23-project-fence.md)
also passes source checks; [real private-adapter preparation](diagnostics/2026-10-23-project-preparation-runtime.md)
now passes. Public routes and member lifecycle remain to be connected; initial anchor Start now has the private source path described below.
[Published duplicate projects passed in VM23-03](diagnostics/2026-10-23-published-project-isolation.md).
[Actual-ship anchor trial05 failed at its post-restart endpoint probe](diagnostics/2026-10-23-anchor-trial05.md);
the corrected [VM23-08 recovery case now passes independent verification](diagnostics/2026-10-23-anchor-state-recovery.md), with clean shutdown and retained originals. A separate
no-ship real-adapter VM23-07 passed and its original evidence is retained. [Creation uncertainty refinements](diagnostics/2026-10-23-project-refinement.md)
pass source checks; the frozen appliance predates them and its inspections now
pass current pure validators. [The initial anchor Start model](diagnostics/2026-10-23-anchor-start-model.md)
and complete namespace-membership resolver pass source checks. [Schema25 durable
Start and its private worker](diagnostics/2026-10-23-anchor-start-journal.md) now pass
source and original-reader checks. [The actual adapter and private server scheduling](diagnostics/2026-10-23-anchor-start-adapter.md)
pass source tests. [VM23-09](diagnostics/2026-10-23-anchor-start-trial09.md) reached
Start but refused a missing helper path; its uncertainty/cleanup and originals are
retained. [Fresh VM23-10](diagnostics/2026-10-23-anchor-start-runtime.md) now passes
real initial anchor Start with independently verified journals and clean cleanup.
[Schema26 member storage](diagnostics/2026-10-23-member-storage.md) now passes
source, temporary-filesystem and original-reader tests. [Private server scheduling](diagnostics/2026-10-23-member-storage-queue.md)
now passes source checks. [Fresh VM23-11](diagnostics/2026-10-23-member-storage-runtime.md)
passed real queued empty-storage preparation and independent disk verification.
[Read-only member namespace observation](diagnostics/2026-10-23-member-observation.md)
now passes source checks, together with the [negative mount-conflict preflight](diagnostics/2026-10-23-member-mounts.md).
[The initial member launch controller](diagnostics/2026-10-23-member-launch-model.md)
now passes source tests. [Schema27 SQLite wiring](diagnostics/2026-10-23-member-launch-store.md)
passes interruption, worker, full managed race and original-reader checks. [The concrete workspace/pill/Docker adapter and private queue](diagnostics/2026-10-23-member-launch-adapter.md)
now pass source tests. [Fresh VM23-12](diagnostics/2026-10-23-member-launch-trial12.md)
retained one running launch and correctly refused the second stale dispatch, but
failed clean member shutdown. [Fresh VM23-13](diagnostics/2026-10-23-member-launch-trial13.md)
advanced to second-member Create, but refused stale Start and again failed early
member cleanup. [Exact-container batching](diagnostics/2026-10-23-member-observation-batch.md)
passes source tests; [trial14](diagnostics/2026-10-23-member-launch-trial14.md)
completed both running receipts but failed its cold-boot HTTP/cleanup gate. The next
[fixture now restores serial identity warmup](diagnostics/2026-10-23-member-readiness-preparation.md)
with time based on prior measured boots. [VM15 now passes](diagnostics/2026-10-23-member-readiness-runtime.md)
both launches, durable readiness, replay/reopen and clean fixture shutdown, with
independently verified database/filesystem evidence and retained originals.
[The pure readiness model](diagnostics/2026-10-23-member-readiness-model.md) passes
source tests; [the concrete collector](diagnostics/2026-10-23-member-readiness-adapter.md)
now passes inert-engine/temporary-filesystem checks. [Schema28 readiness persistence](diagnostics/2026-10-23-member-readiness-store.md)
passes source and original-reader checks; [private readiness scheduling](diagnostics/2026-10-23-member-readiness-queue.md)
also passes source checks. The guarded real readiness gate now passes in VM15.
Durable Stop/resume/recovery and public integration remain. Neither transport test qualifies the new lifecycle by itself. These are implementation tasks, not a need for
user action.
[The pure initial member Stop model](diagnostics/2026-10-23-member-stop-model.md)
now passes inert-driver tests; [schema29 Stop persistence](diagnostics/2026-10-23-member-stop-store.md)
passes source/original-reader checks. [The concrete Stop adapter and private queue](diagnostics/2026-10-23-member-stop-preparation.md)
now pass source tests. [VM16 durable Stop](diagnostics/2026-10-23-member-stop-runtime.md)
passes both queued graceful exits, replay/reopen and independent disk verification.
Recovery, resume and public integration remain pending.
[Read-only recovery observation](diagnostics/2026-10-23-member-stop-exit-source.md)
now passes model/adapter source tests. [Schema30 recovery persistence](diagnostics/2026-10-23-member-stop-exit-store.md)
passes source and original-reader checks. [Private recovery queue and appliance17](diagnostics/2026-10-23-member-stop-exit-preparation.md)
pass source/preparation checks. [VM17 recovery](diagnostics/2026-10-23-member-stop-exit-runtime.md)
now passes independent runtime verification; its outer-shell143 discrepancy remains recorded.
[Exact stopped-container retirement](diagnostics/2026-10-23-member-retirement-source.md)
passes source model/adapter tests. [Schema31 retirement persistence](diagnostics/2026-10-23-member-retirement-store.md)
passes source and original-reader checks. [Private retirement scheduling and project gates](diagnostics/2026-10-23-member-retirement-queue.md)
pass source checks. [Appliance18](diagnostics/2026-10-23-member-retirement-preparation.md)
adds a guarded real retirement/state-byte comparison. [VM18 retirement](diagnostics/2026-10-23-member-retirement-runtime.md)
now passes independent disk/byte/receipt verification.
[Replacement intent](diagnostics/2026-10-23-member-resume-model.md) and
[the concrete first-replacement adapter](diagnostics/2026-10-23-member-resume-adapter.md)
pass source tests. [Schema32 persistence](diagnostics/2026-10-23-member-resume-store.md) and
[private scheduling](diagnostics/2026-10-23-member-resume-queue.md) also pass source checks.
[The read-only replacement-readiness model and adapter](diagnostics/2026-10-23-member-resumed-readiness-source.md)
and [schema33 persistence/private queue](diagnostics/2026-10-23-member-resumed-readiness-store.md)
pass source and original-reader checks. [VM19's first replacement now passes](diagnostics/2026-10-23-member-resume-runtime.md),
with original disks retained. Runtime readiness and general generation handling
remain; VM19 is frozen schema32 and cannot qualify the newer readiness collector.
No production access or additional permission is needed for these experiments.
The goal service reports active after the user resumed; there is no current
implementation blocker. See [development memory](development-memory.md)
for decisions, supersession links and evidence limits.

## Earlier checkpoint record

The [completed history checkpoint](diagnostics/2026-10-22-application-history.md)
passed on final frozen run `09`: real CLI + approval pane + declared Theme/DMs
receivers + private Secret Service, with direct reads/SSE and independent cleanup.
Fully reconciled rows can be archived without replaying old approvals. Fixture
suites cover 96 cycles, interrupted publication and older helper cleanup. The old
experimental collector refuses the new issuer format. The fresh fake shut down
cleanly. Permanent replay receipts and all retained helpers remain preserved;
reference-coordinated helper-cache pruning is still unimplemented.

Core import work now has both the [layout fixture gate](diagnostics/2026-10-22-import-layout.md)
and the [actual guided UI checkpoint](diagnostics/2026-10-22-import-ui.md). Real
components/callbacks passed reviewed destination/consent, uncertain acknowledgements,
progress, retained failure, revision-bound recovery and explicit stopped completion.
They do not qualify a real pier/runtime import.

A signed private QEMU 11.1.2 bundle is ready at
`/tmp/omabit-import-vm-tools-20261022`. The reusable minimal guest driver passed on
`/tmp/omabit-import-vm-smoke-20261022-04` with software emulation and clean poweroff;
this environment has no accessible KVM. That smoke run completed; the later live
import run is tracked below.
The [offline full-system guest checkpoint](diagnostics/2026-10-22-import-guest.md)
now passed on fresh guest run `02` using appliance `04`: real signed native
packages, systemd, Omabit installer, rootless Docker 29.9.1, verified package
provenance, exact offline OCI loading and Vere 4.6 version execution. It powered
off cleanly in 200.58 seconds. No ship was created or operated. An earlier 4 GiB
trial hit its lab-only memory cap; the successful VM used an 8 GiB scope because
temporary disk writes count alongside guest RAM. Failed disks/logs are preserved.
The [first real trials](diagnostics/2026-10-22-import-runtime-trials.md) now proved
fresh fake boot/clean stop, unchanged guided preview, named same-filesystem import,
stopped completion and terminal-request replay through the actual collector. Trials
03 and 04 failed during explicit Start because the minimal guest first exposed only
one CPU, then lacked a TCP networking module. Both failures retain their receipts,
piers and clean guest shutdown evidence. Those trials did not establish the full start/identity/mount gate; the later pass is recorded below.
[Trial 05 passed](diagnostics/2026-10-22-import-runtime.md) using appliance 06:
real import preserved bytes/metadata/inode and stayed stopped, explicit Start
verified identity and the exclusive parent mount, and explicit Stop completed.
The fresh guest powered off cleanly in 727.05 seconds. Its disk was extracted
offline into `/tmp/omabit-import-inspection-20261022-05`; no live job remains.
The [copy-case preparation](diagnostics/2026-10-22-import-copy-trials.md) now uses
a fresh separate guest disk. Trial 06 failed during source boot on the host user's
temporary-storage quota, before importing. Its failed original disks are retained;
redundant converted inspection disks were removed only after checking their originals.
The driver now admits and monitors quota headroom. Trial 07 exited before launch
on a corrected evidence-path typo. [Trial 08 passed](diagnostics/2026-10-22-import-copy.md):
the actual runner copied 7 files / 1,016,823,820 bytes across distinct filesystems,
verified every byte, removed the holding source and completed stopped. Explicit
Start/identity/mount/Stop all passed, with clean guest poweroff in 785.44 seconds.
Offline receipts are in `/tmp/omabit-import-inspection-20261022-08`. Its redundant
converted disk and the earlier appliances' regenerable staging trees were removed
after verifying retained original images; original disks/receipts remain.

[Trial 09 passed](diagnostics/2026-10-22-import-interruption.md) the narrower
partial-copy preservation checkpoint using appliance 08. It stopped only the
private guest runner after progress, restarted it, and verified a complete held
source, a 44,564,480-byte partial destination, the interrupted-operation fence,
no implicit runtime and an unchanged `recover-import` refusal. The guest powered
off cleanly in 728.66 seconds; no live VM job remains. Original disks and offline
receipts in `/tmp/omabit-import-inspection-20261022-09` are retained. Its redundant
conversion was removed after original-image and extracted-result verification.

The [runner/CLI restoration checkpoint](diagnostics/2026-10-22-import-restore-integration.md)
now passes source tests. A read-only preview exposes the two moves and digest;
`restore-import` requires operator access, pinned runner, current revision and
explicit reviewed confirmation. Schema22 persists its journal and fences older
readers. Completion atomically retires the failed registration while preserving
replay receipts and the tombstone revision. Six affected race suites passed, along
with original schema21 writer reproduction and downgrade refusal, client/RPC
validation and twelve private built-CLI smoke cases. No production install occurred.

[Trial10 passed actual restoration and re-import](diagnostics/2026-10-22-import-restore-runtime.md)
in the private VM: both retained filesystem objects survived, terminal replay
preserved retirement and the new revision-2 registration, and explicit
Start/identity/exclusive-parent-mount/Stop passed. Clean poweroff took 849.99
seconds. The 69 offline receipts and original disks are retained; no live job
remains. Earlier run09's originals were moved to persistent task evidence with
verified hashes and compatibility directory links to free temporary quota.

[Guided restoration UI now passes](diagnostics/2026-10-22-import-restore-ui.md)
actual offscreen QML with inert dispatch. It requires a fresh actor/runner/revision
and reviewed moves, explicit consent, and exact receipts; uncertain acknowledgements
stay pending. Completion remains visible after the failed instance disappears,
and late callbacks cannot erase terminal proof. The affected collector/collection
race suites, standard model checks, Qt6 parsing and operator skill validation pass.
The final private screenshots/dispatches are in `/tmp/omabit-restore-ui-20261022-03`.

[Trial11 passed actual UI-to-VM restoration](diagnostics/2026-10-22-import-restore-ui-runtime.md)
with appliance10 and the real collector/runner: one QML preview, explicit consent,
one restoration despite a duplicate signal, and a retained receipt after retirement.
Independent checks confirmed both original filesystem objects survived, terminal
replays preserved both retirement and revision2, and fresh re-import plus explicit
Start/identity/exclusive-parent-mount/Stop passed. Clean poweroff took 865.45 seconds.
The private PySide6/Qt package set has 210 signed packages; the host received no
installation. All 74 offline result files and the original disks remain; no live
VM job remains. Qt produced no warnings/errors. The read-only database check
passed after correcting an offline verifier's schema/instance-shape assumptions.

Trial10's originals were relocated with verified hashes to the task evidence
directory, retaining compatibility links. Regenerable packaging trees and the
verified trial11 inspection conversion were removed for quota headroom.
Empty targets, full disks, process crash/power loss, device renumbering and native
Quickshell lifecycle remain open. The preceding reports keep their original scope
and hashes. No production source or service was accessed.

The next bounded feature checkpoint is the first project fake-network transport
proof: two fresh fake galaxies in one private namespace, with distinct HTTP ports,
bidirectional authenticated application messages, then restart and duplicate
identity isolation in another project. Use the [pinned runtime source notes](project-fake-networks.md)
and the existing disposable VM boundary. Native integration and remaining import
failure gates remain explicit acceptance work; this is not release completion.

The [initial operator entry point](diagnostics/2026-10-22-operator-entry.md) now
has portable source instructions and eleven checked help paths. `logs` and
`login-code` help no longer demand live authority. The collector race suite and vet
passed. [Offline task-family guidance](diagnostics/2026-10-22-task-help.md) now passes
both JSON/text namespace smoke checks and the collector race suite. The built-CLI
simulator also passed five tasks: pinned selection, stale-revision review, exact
asynchronous receipt, unavailable-state reporting and replacement-identity refusal.
Transport-loss/import-recovery walkthroughs, structured runtime next actions,
skill distribution and remaining roadmap gates stay in scope. The new
[plugin developer skill](diagnostics/2026-10-22-developer-skill.md) records standalone
sign-in, optional independent approval, direct data flow, named backend installation,
Omart discovery, private chains and complete profile isolation. It is source guidance;
using it to build a qualified application and shipping it remain open.

Full native desktop/profile integration remains distinct: the actual approval UI
was offscreen with inert style values; Theme's desktop adapter and DMs' native
launcher were disabled. Full plugin overlay/hooks/IPC isolation, writes/reconnect,
hosted compatibility and stable/dev/edge switching remain. Next stages should use
the private desktop or inert adapters, never the active desktop or existing ships.

Keep every production exclusion. Plugins retain independent storage, direct data
transport and standalone login; no shared client package or app-data proxy has
been introduced. Wallet work remains research notes only.

The [first private fake-network trial](diagnostics/2026-10-22-fake-network-trials.md)
confirmed namespace isolation, distinct verified HTTP/admin endpoints and independent
sessions, but the first cross-ship message did not complete. Both test ships and
the VM stopped cleanly. Original disks and offline receipts are retained. No
transport/restart pass is claimed. The next fresh run adds same-ship controls and
credential-free failure diagnostics to separate request compatibility from peer
transport; production exclusions remain unchanged.

[The second private network trial](diagnostics/2026-10-22-fake-network-controls.md)
reproduced a 90-second curl timeout in the same-ship control, before peer transport.
Both fresh ships and the VM stopped cleanly; original disks and verified receipts
remain. Diagnose the HTTP/thread path with the exact binary before another Docker
networking trial. The current CLI/skill now explicitly distinguish shared storage
folders from communicating fake networks; offline guidance checks pass.

[The exact-runtime Eyre channel control now passes](diagnostics/2026-10-22-eyre-channel-control.md):
a fresh native fake accepted a nonce-bearing poke and returned the expected deliberate
application rejection through matched SSE receipts. Both channels closed and the
ship stopped cleanly. All diagnostic scopes are inactive. The Docker probe now uses
this tested protocol; its three receipt-matching tests pass, but its revised real
transport/restart trial remains the next gate. No production installation occurred.

[The Docker peer messaging/session-recovery checkpoint now passes](diagnostics/2026-10-22-docker-peer-recovery.md).
A fresh private VM verified both message directions, an intentional remote Gall
rejection, and both directions after cleanly resuming the same pier in a replacement
container with the original sessions. Two local controls and all five peer outcomes
were independently checked; both ships and the VM stopped cleanly. Original disk
and receipt hashes were verified. Six focused offline tests pass.

The direct remote Eyre probe was disproved by HTTP500; the corrected built-in local
Khan thread was first proven with two fresh native peers. The first native pair's
4 GiB OOM remains failed evidence; a fresh pair at 8 GiB passed. Current experiments
are stopped. This completes only the first transport rung and session/process
recovery. Next: persistent application state, subscriptions and client reconnect,
then duplicate-identity project isolation. Runner integration, publication, anchor
recovery, private chains and the rest of the platform roadmap remain unfinished.
Production ships, installed plugins, tmux and `~/temp-ur` remained excluded.


[Fresh native application-state/subscription recovery now passes](diagnostics/2026-10-22-application-state-native.md).
Four unique peer writes persisted, the queued update and original channel survived
the receiver restart, and a fresh subscription reconciled the full state without
replaying writes. Both ships stopped cleanly. Eleven offline checks pass. The same
case is being prepared in a fresh no-NIC Docker VM; Docker acceptance and duplicate
project isolation remain open. Development memories track the fixture corrections
and explicitly superseded hypotheses in development-memory.md.


[Docker application-state/subscription recovery passed](diagnostics/2026-10-22-application-state-docker.md)
on guest16/appliance15 with independent receipt/hash verification and clean VM
poweroff. Original evidence is retained. The next private VM repeats recovery in
two concurrent projects with the same identities and ports, then tests crossed
sessions and independent writes. Runner integration/publication remain separate.

The [four-fake project isolation run](diagnostics/2026-10-22-docker-project-isolation.md)
passed and its verified originals are retained. No project VM remains live. The
next separate HTTP fixture will qualify publication and anchor recovery.

[Login-selection trial21](diagnostics/2026-10-23-login-selection-trial21.md) stopped
before backend code retrieval because the fixture had not waited for a fresh
resource/container observation. Import/healthy Start passed; the fixture is
corrected and the original failed evidence retained. The direct published Urbit
case from [M034](diagnostics/2026-10-23-published-preparation.md) is now running in
its separate fresh VM. Neither case is yet a runtime pass for administrative
discovery or actual publication.

[Current replacement Stop intent and historical validation](diagnostics/2026-10-23-member-resumed-stop-model.md) now pass pure source checks. Adapter/store integration remains.

[Replacement Stop adapter](diagnostics/2026-10-23-member-resumed-stop-adapter.md) now passes source checks; current-generation persistence/scheduling remains in progress.

[Schema34 replacement Stop persistence and private scheduling](diagnostics/2026-10-23-member-current-stop-store.md) pass source, full managed race and original-reader checks. Actual queued replacement Stop and later generations remain pending.

[VM20 readiness trial](diagnostics/2026-10-23-member-resumed-readiness-trial20.md) was refused before admission because the fixture reused an earlier request ID. Its original disks and clean cleanup evidence are retained. A corrected new run is being prepared; actual resumed readiness remains unqualified.

[Later-generation lifecycle adapters](diagnostics/2026-10-23-member-later-generation-adapters.md) pass source checks through generation4. Repeated-resume persistence and later-generation real runtime qualification remain pending.

[VM21 replacement readiness and Stop](diagnostics/2026-10-23-member-current-stop-runtime.md) pass independent runtime verification, replay/reopen and clean shutdown. Later-generation and runner application-state recovery remain.

[Conversion storage admission](diagnostics/2026-10-23-extraction-storage.md) now uses full virtual size plus verification reserve. Quota-failed source regression is retained and being rerun after VM evidence retention.

[Repeated member replacements](diagnostics/2026-10-23-member-repeated-resume-store.md) pass schema35 migration, generations3/4 queue/replay, original-reader refusal and the full managed race suite. Fresh VM22 qualification is next; application-state recovery remains separate.

[Appliance22 generation3 preparation](diagnostics/2026-10-23-member-repeated-preparation.md) independently verifies all171 sources and embedded code. Its fresh offline VM is running; runtime and application-state acceptance remain open.

[Runner application recovery source fixture](diagnostics/2026-10-23-runner-application-recovery-source.md) passes offline phase/transport/routing checks and host refusal. It will use a new appliance after the generation3 run; real application recovery remains pending.

[Appliance23 application recovery preparation](diagnostics/2026-10-23-runner-application-recovery-preparation.md) verifies all174 sources and embedded helpers. It remains unbooted while VM22 runs.

[Offline project-plan CLI](diagnostics/2026-10-23-project-plan-cli.md) passes source, collector race and five namespace-isolated built-binary cases. It reserves/starts nothing and does not contact runners; lifecycle/public API acceptance remains separate.

Current-context Stop and following private queues pass the [focused schema37 source gate](diagnostics/2026-10-23-current-context-lifecycle-store.md); full managed regression now passes in972.505s. Frozen VM25 remains schema36.

The pure coordinated retirement gate passes ([M146](diagnostics/2026-10-23-anchor-retirement-model.md)); its concrete adapter is under test. VM28 remains the pending read-only anchor review trial.
