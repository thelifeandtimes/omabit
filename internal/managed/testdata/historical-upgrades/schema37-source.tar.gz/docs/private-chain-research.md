# Private local Ethereum chain — source constraints

Research only, 2026-10-22. No node, contract, wallet or ship was started for this
research. The first supported path remains a private local development chain;
public testnets and mainnet forks are outside this initial goal.

The pinned Vere commit `5a7614f69bbc783736b08965fdc0a2534bb42e82` exposes
`--ethereum` separately from `--local` and `--fake`. A gateway URL alone is not
evidence that the ship uses the intended Azimuth network.

The local Arvo reference checkout at `50c7f5239610fc72263df7aa99b4d171cfe9d408`
has an explicit `%local` selection in `gen/azimuth/watch.hoon` and
`lib/dice.hoon`. Its `base-dev/lib/azimuth.hoon` defines a fixed local contract
set and chain ID 1337, with a comment tying the addresses to Bridge deployment.
Consequently, an arbitrary fresh chain/contract address is not automatically
compatible with the existing `%local` path. This is a source inference, and must
be checked against the actual pinned pill before implementation.

| Reference input | SHA256 |
| --- | --- |
| pkg/base-dev/lib/azimuth.hoon | f64ce94c0dbb8d7b5f28e0abb9e9d7d25e6169c8aabf59e7183cf84f9fe8ec45 |
| pkg/arvo/lib/dice.hoon | 3b6e3bfcf00dda7f1899b71d50a248e9af16fa208423a111689a8b58f9a5a7db |
| pkg/arvo/gen/azimuth/watch.hoon | 88c96b69a4a58e8558d4e79da48735ad74ad897785daeaa8ef58a1cf08409501 |

Bridge documents a local Ganache/Azimuth development flow and a fake-ship L2
setup. Treat it as reference material to qualify, not a script to invoke on the
user's desktop. [Bridge development documentation](https://github.com/urbit/bridge/blob/master/DEVELOPMENT.md).

Its inspected package scripts set chain ID 1337, bind the development node to
all interfaces, and use process-name cleanup. An Omabit lab must instead bind
inside its private boundary and terminate only its own child process/container.
Record the exact deployment/runtime inputs and preserve the user-visible project
identity. [Bridge package scripts](https://github.com/urbit/bridge/blob/master/package.json).

Azimuth's repository separates on-chain storage from Ecliptic's mutation interface
and documents local contract tests. Its mainnet-fork scripts are a different
workflow and are not a prerequisite here. [Azimuth source and test instructions](https://github.com/urbit/azimuth).

The next chain experiment should freeze the dependency/deployment artifacts, then
verify chain ID, genesis identity, contract addresses/code and fresh dev key
ownership in an isolated node. Qualify actual ship observation of those keys before
calling the setup a ship devnet. After that, test peer messages, restart and chain
state retention with exact project ownership. Never derive production identities
from public development seeds or present those seeds as wallet storage. The wallet
security research remains separate in platform-security-notes.md.

A collection profile should select a pinned chain/project artifact and explicit
ship endpoints; switching profiles must not silently reset the chain or repoint
existing ships. Preserve old project state while changing client collections.
