package main

import (
	"errors"

	"git.thechristophgroup.org/thelifeandtimes/omabit/internal/client"
	"git.thechristophgroup.org/thelifeandtimes/omabit/internal/credentials"
	"git.thechristophgroup.org/thelifeandtimes/omabit/internal/eyre"
	"git.thechristophgroup.org/thelifeandtimes/omabit/internal/protocol"
)

// Guidance is collector navigation, not a runner capability or an instruction
// to execute a repair. Preserve the established error object and exit codes.
type guidedErrorResponse struct {
	Error    protocol.APIError `json:"error"`
	Guidance *errorGuidance    `json:"guidance,omitempty"`
}

type errorGuidance struct {
	Kind    string        `json:"kind"`
	Summary string        `json:"summary"`
	Next    []helpCommand `json:"next"`
}

func guidanceFor(err error, problem protocol.APIError) *errorGuidance {
	if errors.Is(err, client.ErrIdentityMismatch) {
		return &errorGuidance{Kind: "resolve_runner_identity", Summary: "Stop mutations through this selection. Resolve the intended runner before reconnecting; do not overwrite enrollment to suppress the mismatch.", Next: []helpCommand{
			{"runners", "Read the saved identities locally using the same collector registry."},
			{"help runners", "Read offline selection and identity guidance."},
		}}
	}
	if errors.Is(err, eyre.ErrIdentity) || errors.Is(err, eyre.ErrRedirect) {
		return &errorGuidance{Kind: "resolve_ship_origin", Summary: "Resolve the intended ship and origin before signing in or changing enrollment. Preserve the saved identity and credentials while reviewing the mismatch.", Next: []helpCommand{
			{"ships", "Read locally saved ship identities and origins using the same collector registry."},
			{"help connections", "Read offline connection and identity guidance."},
		}}
	}
	var uncertain *client.OutcomeUncertainError
	if errors.As(err, &uncertain) {
		return &errorGuidance{Kind: "reconcile_uncertain_request", Summary: "The mutation outcome is unknown. Preserve the original request ID, actor, target and effect. Do not retry with a new ID or submit an inverse action. An absent receipt during an outage does not prove rejection.", Next: []helpCommand{
			{"snapshot", "When the same pinned runner is reachable, read its state and receipts; match the original request and actor before deciding any continuation."},
			{"help ships", "Read offline receipt and interruption guidance. Other mutation families have their own state/recovery rules."},
		}}
	}
	var remote *client.RemoteError
	if errors.As(err, &remote) && problem.Code == "revision_conflict" {
		return &errorGuidance{Kind: "review_current_revision", Summary: "Read the current state and review the intended effect before acting. Do not blindly replace the revision or retry.", Next: []helpCommand{
			{"snapshot", "Read current state and operation receipts from the same pinned runner."},
			{"help ships", "Read offline revision and operation guidance."},
		}}
	}
	if errors.Is(err, credentials.ErrStore) {
		return &errorGuidance{Kind: "restore_credential_access", Summary: "Credential storage is unavailable or refused access. Preserve the existing session and resolve access to the configured store; do not switch adapters or create a plaintext fallback.", Next: []helpCommand{
			{"ships", "Read local connection metadata and the configured credential adapter."},
			{"help connections", "Read offline session and cleanup guidance before changing credentials."},
		}}
	}
	if errors.Is(err, credentials.ErrMissing) || errors.Is(err, eyre.ErrAuth) {
		return &errorGuidance{Kind: "review_ship_login", Summary: "The selected session is absent or rejected. Review the intended connection before a new sign-in; keep +code on stdin and out of arguments or reports. This does not prove the ship is stopped or missing its backend.", Next: []helpCommand{
			{"ships", "Read locally saved ship identities and origins using the same collector registry."},
			{"ship-login --help", "Read the explicit sign-in contract without contacting a ship or reading credentials."},
		}}
	}
	return nil
}
