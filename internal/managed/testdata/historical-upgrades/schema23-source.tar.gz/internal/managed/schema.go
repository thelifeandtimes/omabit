package managed

// StateSchemaVersion is also queried from the built runner by release tooling.
// Schema23 fences project ownership and port reservations from earlier readers.
// Migration adds empty project tables while preserving legacy bodies and replay
// receipts. Opening the store does not create or adopt any runtime resources.
const StateSchemaVersion = 23
