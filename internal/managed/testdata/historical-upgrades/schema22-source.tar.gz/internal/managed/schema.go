package managed

// StateSchemaVersion is also queried from the built runner by release tooling.
// Schema22 fences durable source-restoration journals and retirement receipts
// from old readers that would discard the recovery intent. The version-only
// migration accepts schemas11–21 without rewriting bodies or replay records.
const StateSchemaVersion = 22
