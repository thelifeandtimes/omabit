# Runner project integration contract — development draft

This is the next implementation slice after the transport/state and endpoint
experiments. It defines required invariants; it does not advertise a shipped CLI,
select an unqualified topology, or migrate existing instances. See
[project research](project-fake-networks.md), [isolation](experiment-isolation.md),
and [upgrade policy](upgrade-policy.md).

## Identity and opt-in membership

A project has a runner-generated immutable ID and a separate editable display
label. A storage folder, fake ship name, instance ID, collector enrollment or
plugin profile is not a project ID. Only explicitly requested fresh fake members
join the first implementation. Existing standalone fake/live instances remain on
their recorded topology and ports; importing or moving storage does not join a
network. Ethereum chains and cross-runner transport have separate contracts.

Persist the project identity, revision, mode, member instance/runtime IDs, and
selected fake identities before dispatching resources. A fake identity is unique
within one project but may repeat in another. The initial qualified member set is
galaxies, matching the proven local discovery path. Reject unsupported identity
classes explicitly rather than inferring that arbitrary fake planets behave alike.

All project members are trusted development participants sharing loopback and
administrative HTTP. Independent piers and process/container ownership do not
provide inter-member administrative isolation. A project description must say so.

## Endpoint ownership

Public Eyre ports are explicitly allocated inside the shared namespace and mapped
only to reserved IPv4 runner-loopback ports. Never publish Lens, conn.sock, Ames,
wildcard addresses or IPv6 implicitly. Plugin traffic goes directly to Eyre;
collector RPC is not a transport proxy. Verify the selected ship at each endpoint.

The pinned Vere image also declares `/urbit` as a data volume and working directory.
A namespace-only anchor must explicitly account for that storage (for example, a
qualified bounded ephemeral mount); it must not acquire unjournaled persistent
volumes as an incidental Docker image default. Inspect its image environment,
mounts and containment independently of member pier mounts. See memory M047.

Anchor publications are immutable Docker creation settings. The first slice
requires the complete initial member/port reservation set before creating an
anchor. Adding/removing bindings is a reviewed maintenance operation with every
member stopped; it cannot silently replace an anchor or disrupt running peers.
Do not invent a hidden capacity limit or reserve an arbitrary host-port range to
avoid this lifecycle. Existing host-port reservations and actual binding conflicts
must participate in the same runner transaction/admission as standalone instances.

Administrative ports are discovered per pier from `.http.ports` and bound to the
current exact container/ship identity before code retrieval. The source discovery
prerequisite is documented separately. A saved port is not durable authority.
Shared-project integration must also replace the remaining internal public8080
assumptions in command construction, inspection, readiness and publication.

## Resource journals and reconciliation

Record exact Docker engine, bridge and anchor identities, immutable labels/options,
publication sets, member attachments and lifecycle generations. Names/labels alone
cannot authorize adoption or removal. Persist create/start/stop uncertainty before
dispatch, with actor-scoped request replay and the expected project/instance
revisions. Observe accepted work by its original receipt; no inverse mutation or
fresh request ID is an automatic response to a lost reply.

A bridge/anchor is project-owned, never owned by the first member's individual
cleanup routine. Stopping or retiring one member cannot remove a peer's namespace.
Start verifies the current anchor, exact namespace membership, complete reserved
endpoints and unchanged pier ownership. Late/repeated completion from an older
lifecycle generation cannot publish a newer generation as ready.

| Observation | Required behavior |
| --- | --- |
| One member cleanly stops | Keep anchor/bridge and other members running; retain that member's pier/slot |
| Member resumes | Create a replacement container from the same pier in the verified current anchor namespace; do not reuse boot flags |
| Anchor unavailable with live members | Mark the project degraded/uncertain; retain old membership evidence; do not start another anchor or move members |
| Anchor returns with a different namespace | Keep the old and new observations; require coordinated member stop/replacement before readiness |
| Unknown attachment or replaced resource | Refuse mutation/adoption and retain evidence |
| Collector/runner restarts or a second operator arrives | Reopen the same durable intent; revision/replay rules prevent duplicate resources |
| Project retirement | Require all members stopped and all lifecycle outcomes resolved; preserve piers unless separately authorized |

Reconciliation needs fresh observations under a runner-wide project mutation
fence, including the engine identity and all known members. Namespace inode numbers
are observations tied to one boot/resource generation, not portable identities.
Do not infer successful cleanup from a single empty inventory after uncertainty.

## Compatibility and acceptance

The schema must advance before project membership/runtime journals are persisted,
so older readers refuse rather than discarding this state. Migration preserves
legacy bodies, signatures, replay records, ports and running/stopped intent.
Opening a store does not create a network, start a ship, or reclassify a directory.
New features use explicit capability negotiation; older runners stay observable.

Implement in bounded slices: transactional project/membership records with replay
and downgrade tests; a driver with exact resource validation and uncertainty
journals; CLI read/preview/explicit action; fresh private-VM integration; then UI.
The first real runner gate must demonstrate two fresh galaxies, direct authenticated
messages, independent stop/resume, durable application/subscription state and exact
public/admin identity. Follow with simultaneous duplicate-identity projects,
anchor failure/recovery, interrupted dispatch and manager restart. Earlier fixture
passes remain scoped evidence, not automatic qualification of this new driver.

## Current implementation slice

The [offline planner](diagnostics/2026-10-23-project-planner.md) and
[durable reservation store](diagnostics/2026-10-23-project-store.md) now pass source
checks. Schema25 preserves complete planned projects and actor-scoped receipts;
standalone registration/allocation respects their claims. Canonical digests are
review data, not stable project IDs or runtime authorization. [Runtime ownership assessment](diagnostics/2026-10-23-project-observation.md)
now passes source checks. [Durable preparation journals](diagnostics/2026-10-23-project-journal.md)
retain bridge/anchor dispatch and exact returned IDs under schema24. Resource
dispatch now has private preparation and initial Start paths; member lifecycle,
recovery, capabilities and CLI/UI remain to be integrated.
The pure assessment alone is not persistent authority. The original
schema22 snapshot refuses actual schema23 project state; no live store was changed.

The [private Docker adapter](diagnostics/2026-10-23-project-adapter.md) and
[server work/update fencing](diagnostics/2026-10-23-project-fence.md) now pass inert
source tests. [Further review](diagnostics/2026-10-23-project-refinement.md) preserves
complete returned creation IDs on client errors and requires a never-started
anchor. These supersede the missing-adapter/fencing portion of the current slice
above. [Real preparation](diagnostics/2026-10-23-project-preparation-runtime.md) now
passes. [Schema25 Start journaling](diagnostics/2026-10-23-anchor-start-journal.md)
and [the private adapter/queue](diagnostics/2026-10-23-anchor-start-adapter.md) pass
source tests; [fresh VM23-10](diagnostics/2026-10-23-anchor-start-runtime.md) now
passes real initial Start with independent receipt and cleanup verification. Member ownership/piers,
readiness collection, recovery and public routes remain unfinished.
Prepared resources must never be described as communicating ships or as a ready
project merely because the creation journal completed.
