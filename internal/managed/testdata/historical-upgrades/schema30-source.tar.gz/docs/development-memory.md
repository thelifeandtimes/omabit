# Omabit development memory

Keep stable decision IDs, dates, status, evidence and explicit supersession links.
A newer passing experiment does not erase a failed run or broaden its claim.
Update this log as development proceeds; do not store credentials here.

## M001 — Product and ownership (2026-10-22, current)

Omabit is the ship runner; Tend is separate at thelifeandtimes/tend. The product
anchor is “Multiplayer apps without a subscription”. This supersedes the retired
monorepo's four-workstream description for current platform development.

## M002 — Production exclusions (2026-10-22, current)

Protect managed ~lismyl-lismyl absolutely. Never inspect or operate tmux ships or
anything under ~/temp-ur. Preserve installed plugins and production services.
Use fresh disposable ships, isolated engines/namespaces, and separate experimental
plugin IDs, state, credentials and desktop adapters. This supersedes historical
reset/deployment permissions. See experiment-isolation.md and protected-ships.md.

## M003 — Authentication and application ownership (2026-10-22, current)

Prove the contract with Theme and DMs. Omabit provides optional authentication;
plugins communicate directly with Eyre and support standalone URL/+code login.
Give each plugin its own session, while acknowledging that current Eyre sessions
are not desk-scoped. Backend installation belongs to the plugin; discovery belongs
to Omart. Do not grow an Omabit app store. Private Ethereum chains are the first
happy path, with stable/dev/edge profiles isolated across all state and side effects.
These user decisions supersede the initial Tend-first/shared-data-provider framing.
Wallet/key storage is research only; same-user plugins are not a key-security boundary.

## M004 — Fake transport protocol (2026-10-22, current)

Pinned Vere 4.6-5a7614f uses loopback for fake-galaxy discovery. Shared private
network namespaces pass; a bridge-only topology is not qualified. Direct foreign
Eyre pokes failed HTTP500 because Gall refuses foreign poke-as. Use a typed local
Khan thread to send an ordinary Gall poke and verify its bound acknowledgement.
This supersedes the channel-based peer probe; previous failed reports remain valid.
See diagnostics/2026-10-22-fake-network-channel-trial.md and project-fake-networks.md.

## M005 — Docker restart result (2026-10-22, current)

The two-ship Docker test passed messages in both directions, deliberate rejection,
and same-pier replacement-container recovery with original sessions and namespace.
Resume omits creation flags -F/-B/-c. This supersedes the stale “transport unproven”
summary, not the failed historical trials. It does not prove persistent application
subscriptions, power-loss recovery, anchor recovery or project integration.
Evidence: diagnostics/2026-10-22-docker-peer-recovery.md.

## M006 — Goal execution and next evidence (2026-10-22, execution current; test status superseded by M014/M019)

The user explicitly resumed and requested continuous progress through checkpoints
unless actually blocked. A checkpoint is not a request for another approval.
The goal service still reports an old blocked state; its API cannot resume it.
Continue authorized work and record evidence. The next test uses a disposable Gall
state fixture, queued subscription update, same-pier receiver restart, original
channel/cookie reconnection and fresh subscription reconciliation without replaying
writes. Implementation in progress, no pass claimed yet.

## M007 — Fixture setup transport (2026-10-22, partially superseded by M008/M010)

Native state control12 timed out on Lens `|mount %base`, before state writes or
subscriptions. Both fakes stopped cleanly. Lens expression reads worked in earlier
gates, but a mutating Dojo command did not return usable completion here. Replace
this fixture setup with acknowledged typed Gall pokes and read-only readiness
checks. This supersedes only the initial fixture setup assumption; it is not a
failure of persistent Gall state. Retain /tmp/omabit-thread-probe-20261022-12.

## M008 — Acknowledged fixture setup (2026-10-22, superseded by M010/M011)

Control13 proved the replacement mount and commit requests and read-only Clay
readiness, then returned HTTP500 for the fixture start thread. Both fakes stopped
cleanly. Error diagnostics now request JSON for setup, including bound success
receipts and structured failures. Control14 is fresh; no recovery pass claimed.
This narrows M007: mount/commit are resolved, app startup remains under test.
Original control13 retained beside control12 with hashes and compatibility links.

## M009 — Recovery evidence scope (2026-10-22, current)

Clean process restart proves persistent ship/application state only when read back.
It does not imply an agent upgrade invoked on-save/on-load. Bounded SSE connections
prove channel reconnection and subscription delivery; they do not preserve a TCP
socket across process death. A fresh snapshot must reconcile reads without replaying
writes. Theme currently treats subscription facts as invalidations and re-scries
after each gap; that existing source pattern still needs real write/reconnect tests.

## M010 — Fixture startup diagnostic scope (2026-10-22, resolved by M011)

Controls14/15 still failed at start despite JSON setup responses. Read-only Lens
proved the fresh base extra-app map is empty. A minimal fixed rein poke is now
allowed only behind that explicit empty-map check. Do not apply it as a general
installer: preserve existing overrides. The fixture helper was moved outside the
ten public Gall arms. These two corrections are under test; neither is a proven
root cause yet. This supersedes M008's expectation that JSON alone would reveal a
structured start error. See diagnostics/2026-10-22-application-state-trials.md.

## M011 — Concrete fixture compile failure (2026-10-22, current)

Clay's `%ca` endpoint builds an app source file as a vase; `%cb` builds a mark and
was the wrong diagnostic. Diagnostic03 exposed `-find.$` at the duplicate-entry
guard in omabit-state.hoon. Replace the malformed negation/double-call expression
with `?< (lien ...)`. On diagnostic04, changing that guard in a private copy of the
stopped test pier made the same commit/start requests return HTTP200 and a scry
return revision0/empty entries. Both diagnostic03 and 04 stopped cleanly.
This resolves M010's fixture-start investigation; no evidence supports blaming
Docker, foreign transport, or Clay map access for that setup failure. A fresh full
recovery run is still required. Original failing piers remain preserved.

## M012 — Log bounds must not limit pier files (2026-10-22, current)

Do not apply a low process-wide RLIMIT_FSIZE to Vere to cap a diagnostic log: it
also restricts the pier/database files. Diagnostic02's private clone exited during
startup with that mistaken limit; retain it as failed evidence, not a clean-stop
pass. Use the normal harness's bounded pipe capture and outer deadline. This
supersedes the rejected diagnostic-only file-limit approach. Original source piers
and all production data were untouched.

## M013 — Generic noun pokes across Ames (2026-10-22, current)

Fresh control17 compiled/started the fixture and received the initial subscribe
ack/snapshot. Its first peer write was rejected with `nest-fail`, `-have.*`,
`-need.@t` at the input cast. The generic noun mark does not preserve the caller's
cord aura across the remote conversion. Validate the received noun's atom shape
with `;;(@t q.vase)` rather than expecting a typed @t vase. This supersedes the
fixture's typed-vase input assumption; it is not a networking failure. Both fresh
fakes stopped cleanly. Full state/reconnect acceptance remains pending control18.

## M014 — Native state/subscription recovery (2026-10-22, current)

Fresh control18 passes all four peer writes, persisted state, queued event delivery
on the original channel after same-pier receiver restart, continued updates, and
fresh-subscription reconciliation without write replay. Original sessions survive;
both channels and ships clean up correctly. This supersedes M013's pending native
acceptance status and resolves the fixture work in M006–M011. It does not supersede
those retained failures or qualify Docker yet. Evidence and exact limits:
diagnostics/2026-10-22-application-state-native.md. Proceed to the private Docker
VM gate, then duplicate-identity project isolation, without asking for another
checkpoint approval.

## M015 — Next project isolation gate (2026-10-22, provisional)

The four-fake VM harness is prepared but unrun. It keeps A live while B repeats the
same identities/ports in another namespace, then checks crossed cookies and writes
against independent state. Offline checks reject false namespace, liveness, cookie
and state evidence. Increased memory admission applies only to that future private
VM; do not overlap it with the current two-ship state VM. Runner integration and
endpoint publication remain separate design/qualification work. Existing storage
project labels are not durable network IDs. See project-fake-networks.md and the
qualification README for constraints; these notes are not shipped capabilities.

## M016 — CLI uncertain acknowledgement (2026-10-22, current)

The six-task private simulator walkthrough passes an intentionally lost response
after acceptance. Snapshot reconciliation and exact terminal request replay find
one original operation, with no duplicate work. Keep the original request/actor/
effect binding; a missing reply does not establish rejection. This supersedes the
transport-loss-pending portion of the earlier CLI checkpoint. It is simulator
proof only; the first proxy trial's omitted protocol header was a harness failure.
See diagnostics/2026-10-22-cli-lost-reply.md. Structured guidance is the next step.

## M017 — Machine-readable recovery navigation (2026-10-22, current)

Collector errors now optionally include local `guidance` beside the unchanged
error/code: review_current_revision, reconcile_uncertain_request, or
resolve_runner_identity. Typed client uncertainty preserves causes; never infer
it from remote text. Wrapped identity mismatch takes precedence, offering local
reads only. Guidance performs no recovery or retry. The built six-task private
simulator and affected race/vet checks pass. This supersedes M016's pending
structured-guidance status. See diagnostics/2026-10-22-cli-recovery-guidance.md.

## M018 — Skill distribution ownership (2026-10-22, current)

Keep the operator/developer SKILL.md and references together. Release/development
packagers now add a separate source-bound, checksum-covered skills archive; no
agent configuration or installed skills change automatically. Historical exports
without skills keep their original assets. Four focused packaging fixtures pass;
six existing source-isolation checks pass with two full-build/channel checks
explicitly skipped. Frozen end-to-end release packaging remains unqualified.
This supersedes the source-only distribution plan, not the older published release.
See agent-skills.md. Capability discovery remains necessary with older binaries.

## M019 — Docker state/subscription recovery (2026-10-22, current)

Guest16/appliance15 passes the persistent application and subscription gate on the
pinned runtime/private rootless engine. Four unique peer writes, all 13 observations,
original session/channel/cursor recovery after same-pier container replacement,
fresh reconciliation and both channel deletions independently match. Clean shutdown
and original artifacts are verified and retained. This supersedes the Docker-pending
status in M014 and the current-work portion of M006; native/failed evidence retains
its original scope. It does not qualify the newer project-isolation source, runner
integration or endpoint publication. See diagnostics/2026-10-22-application-state-docker.md.

## M020 — Bind delayed DMs work to its original channel (2026-10-22, current)

Offline tests reproduced three stale-session bugs: old backoff cleanup deleting a
new channel, queued ACK targeting the current channel, and late contact results
assigning before the generation check. The experimental DMs bridge now binds
mutations to generation plus channel, serializes reset, and checks before state
assignment. All 24 affected tests pass. This supersedes any assumption that the
previous account-generation checks alone covered reconnect races; it does not
supersede earlier frozen authentication passes or qualify the new real transport.
See diagnostics/2026-10-22-dms-stream-generation.md. Full profile tests remain open.

## M021 — Qualify publication before choosing topology (2026-10-22, provisional)

Loopback-only namespace transport does not prove host endpoint publication. A
separate no-NIC guest case is prepared using HTTP responders and two private
rootless bridge projects. It checks exact IPv4 guest-loopback mappings, identity,
cross-project reachability and anchor replacement/recovery. Native responder and
offline mapping fixtures pass; Docker behavior remains unqualified. Start with
internal bridges; a separately recorded egress-bridge experiment may be needed.
Never repair an anchor by silently stranding running members in its old namespace.
This supplements M015/M019 and replaces no runtime result. See the fake-network
qualification README. No current host publication or runner behavior changes.

## M022 — Real plugin transport control (2026-10-22, provisional)

A new native pair case stages distinct Theme/DMs `auth-lab` artifacts. It exercises
actual settings writes/watch and DMs acknowledgements, invitations, live events
and history before/after receiver restart, without collector data mediation.
Five evidence-rejection tests and private import/profile preflight pass; no runtime
write/reconnect result yet. Keyring persistence and desktop application are inert
for this control and keep their separate acceptance gates. Temporary storage is
admitted/monitored in addition to the existing eight-GiB scope. This supplements
M020; it does not supersede any frozen authentication result.

## M023 — Remaining native profile collisions (2026-10-22, current finding)

Source inspection still finds Theme's fixed `urbit-theme` IPC target and canonical
hook names/plugin path in Service.qml and client/native.py. Namespaced session
metadata alone cannot authorize enabling experimental copies beside the user's
current plugin. Desktop application itself needs explicit collection ownership.
Keep current runtime controls headless/inert and qualify IPC, hooks, launchers and
watcher teardown before stable/dev/edge collection activation. This confirms the
existing profile limitation; no installed desktop was inspected or changed.

## M024 — Actual plugin writes/reconnect passed (2026-10-22, current)

Native plugin control01 passed four unique DMs, both histories/live events, two
exact appearance writes/facts, original sessions, fresh subscription channels and
independent logout after same-pier receiver restart. Originals and 37 frozen inputs
are verified and retained. This supersedes M022's unrun status and qualifies M020's
stale-stream artifact for this transport case. Desktop, persistent credentials,
hosted compatibility and collection profiles keep separate gates. See
diagnostics/2026-10-22-plugin-transport-native.md. Later source changes are not
covered by this frozen pass.

## M025 — DMs requires an explicit positive receipt (2026-10-22, current)

Four new offline tests reproduced eleven failed subcases: missing/unrecognized
positive acknowledgements were reported as completion, bool/float IDs could match
an integer request, and a late duplicate overwrote the first result. Experimental
DMs now requires an integer ID and exact `ok`, preserves the first receipt, and
keeps malformed outcomes uncertain without replaying writes. All 28 affected tests
pass. This supersedes the permissive receipt-handling assumption, not M024's
frozen runtime evidence. A fresh runtime control is required for this new source.

## M026 — Local-chain compatibility is more than an RPC URL (2026-10-22, research)

Pinned Vere separates gateway/local/fake options. The reference Arvo `%local`
path uses fixed contract addresses and chain ID 1337 tied to Bridge deployment.
Verify the actual pill and deployed code/state; arbitrary Anvil/Ganache defaults
are not a qualified ship devnet. Bridge's convenience scripts include broad
process cleanup and wildcard binding, so use owned children in a private boundary
instead. No scripts were run or keys stored. This refines the private-chain plan
without choosing a shipped implementation; see private-chain-research.md for
source hashes, primary references and evidence limits.

## M027 — Strict receipt artifact qualified on native peers (2026-10-22, current)

Native control02 repeats the complete plugin pass with M025's stricter DMs code.
Independent checks now bind all four DM writes to exact wire poke IDs/channels,
positive receipts, receiver events and both histories. Two Theme writes, original
sessions, new subscriptions and independent logout also pass. Originals and
37 frozen input hashes are retained. This supersedes M025's pending runtime status
and M024's newer-source limitation, without changing their historical evidence.
See diagnostics/2026-10-22-plugin-receipts-native.md; persistent keyring/native
desktop/profile/hosted gates remain separate.

## M028 — Distinguish ship credentials from runner state (2026-10-22, current)

Direct Eyre error hints now distinguish origin/identity refusal, unavailable
credential storage and absent/rejected sessions. Use local ships/offline help
without runner selection; no fallback, credential replacement or retry occurs.
Identity/store failure takes precedence over login advice, and transport failure
is not classified as expired authentication. Collector race/vet and JSON/text
CLI fixtures pass, preserving enrollment with no post-enrollment HTTP dispatch.
This extends M017; ship-status keeps its separate result shape. See
diagnostics/2026-10-22-ship-error-guidance.md, including corrected fixture assumptions.

## M029 — Duplicate identities stay within their Docker projects (2026-10-22, current)

Run17 passed two simultaneous zod/nec pairs in distinct loopback-only namespaces.
Each recovered state/subscriptions and original sessions after receiver replacement.
Four crossed same-identity cookies were refused; interleaved fifth writes/readbacks
kept project state disjoint. Original images and 17 extracted files are verified
and retained. This supersedes M015's provisional runtime status and M019's pending
project-isolation gate. Publication, anchor lifecycle and runner integration remain
separate; liveness is source-asserted rather than a duplicated raw inspect trace.
See diagnostics/2026-10-22-docker-project-isolation.md. No production access occurred.

## M030 — Preserve failed endpoint evidence before changing topology (2026-10-22, current)

Endpoint trial18 failed before any member/HTTP request on a publication mismatch,
then failed its sleep-anchor clean-stop assertion. The old fixture omitted raw
mapping/stop observations, so it cannot diagnose exact Docker behavior. Originals
and 18 extracted files are verified and retained. The successor records both and
uses init for anchor signal forwarding; its internal-bridge rerun is pending.
This supersedes M021's unrun status, not its open publication/lifecycle gate.
See diagnostics/2026-10-22-endpoint-trial18.md. Do not turn clean VM poweroff into
an application-test pass or silently discard the failed fixture's history.

## M031 — Discover and identify administrative endpoints (2026-10-22, source-qualified)

Runner code retrieval now reads a bounded, safe `.http.ports` file from the selected
pier and checks Lens identity before and after requesting a code. Endpoint/inventory
changes discard results; no fallback to12321 or cached port is used. Default/named
fake/comet and refusal race tests plus vet pass. This supersedes the unchanged
hardcoded12321 implementation noted in project-fake-networks.md, while preserving
that historical finding. The newer Go path requires its own real-runtime gate;
earlier Python transport controls do not qualify it. See
diagnostics/2026-10-22-admin-endpoint-discovery.md. Public internal8080 and single-
instance networking remain unchanged until project integration.

## M032 — Internal bridge has requested but inactive publications (2026-10-22, current)

Corrected trial19 records exact requested loopback mappings but null active ports
on the running anchor's sole internal bridge in rootless Docker29.9.1. It cannot
satisfy this direct-publication contract. Init fixed clean anchor shutdown in this
successor (exit143, no cleanup error). Images and 18 files are verified/retained.
This supersedes M030's unresolved publication diagnosis for the corrected source
and rejects M021's internal-bridge candidate on this pinned stack. Next is a
separate non-internal bridge inside the no-NIC VM; production topology remains
unselected. See diagnostics/2026-10-22-endpoint-trial19.md.

## M033 — Published endpoints require coordinated anchor recovery (2026-10-23, current)

Ordinary-bridge fixture run20 passed28 HTTP observations, four exact loopback
publications, four IPv6 refusals and four cross-bridge refusals. Restarting the same
anchor replaced its namespace; old members stayed in the old namespace. Explicit
member stop/replacement restored published endpoints while the second project
remained unchanged. Nine clean stops, VM poweroff and retained artifacts/receipts
were independently verified. This supersedes M021's pending publication fixture
and M032's pending ordinary-bridge experiment, preserving both failed internal-
bridge trials. Actual ships on this topology, runner integration and external
reachability remain unqualified; the VM has no NIC. See
diagnostics/2026-10-23-endpoint-publication.md and project-network-contract.md.

## M034 — Direct published fake traffic is a separate runtime gate (2026-10-23, prepared)

The new single-project publication case sends actual Eyre requests directly from
guest loopback, with independent in-memory cookies and bounded SSE reads. Lens
setup remains inside the selected namespace. All32 offline network checks pass;
the fresh appliance and sources are hash-verified. This extends M033 without
promoting its HTTP fixture to Urbit evidence. Actual execution, published duplicate
projects, real-ship anchor replacement and runner integration remain pending.
See diagnostics/2026-10-23-published-preparation.md. No production access occurred.

## M035 — Completed Start is not yet a login-code selection (2026-10-23, current)

Trial21 passed fresh import/healthy Start but immediately requested a code before
the first resource observation named the container. Existing admission refused;
zero access audits prove the endpoint/code backend was not reached. Original
images and43 extracted receipts are verified/retained. The fixture now polls an
exact fresh selection before its one reveal, with10 offline checks passing. This
supersedes the old fixture assumption; M031's real-runtime gate remains open.
Do not diagnose code-discovery timeout from this trial or weaken admission to make
it pass. See diagnostics/2026-10-23-login-selection-trial21.md.

## M036 — Plan endpoints before persisting project ownership (2026-10-23, source-qualified)

The pure project planner validates fresh distinct galaxies, explicit unreserved
host ports and shared-administration consent; it produces deterministic internal
ports and a canonical review digest. Race checks cover input ordering, reservation
conflicts, duplicate identities and altered contracts. It has no persistence, CLI
capability or engine effects. Schema22 source/binary are retained before any later
migration. This implements a prerequisite of project-network-contract.md, not
runner project support. M035 also informed new offline login-code selection help;
existing help and skill-package checks pass. See diagnostics/2026-10-23-project-planner.md.

## M037 — Published Eyre preserves application state and subscriptions (2026-10-23, current)

Run23-01 passed50 direct guest-loopback Eyre requests, four durable writes and13
ordered observations across same-pier receiver replacement. Existing sessions,
queued subscription recovery, a new subscription and independent logout passed.
Exact publications, IPv6/Lens refusals, clean stops/poweroff and retained hashes
were independently verified. This supersedes M034's prepared-only status and
M033's actual-Urbit-publication gap. Published duplicate projects, ship anchor
replacement and runner integration remain open; it is not an external-network or
hostile-member isolation claim. See diagnostics/2026-10-23-published-state.md.

## M038 — Project ownership is durable before runtime dispatch (2026-10-23, source-qualified)

Schema23 atomically reserves complete reviewed projects with stable IDs and
actor-scoped replay. Standalone IDs/ports and project claims share admission;
corrupt claims refuse opening/allocation. Race suites and vet passed. The frozen
schema22 writer reproduced its fixture and its reader refused actual schema23
project reservations unchanged. Full older-writer regeneration hit a missing
local preview18 object; checked-in migration tests passed. This supersedes M036's
schema22/persistence-pending status only. No RPC/capability or runtime dispatch is
implemented, and no live database was upgraded. See diagnostics/2026-10-23-project-store.md.

## M039 — Compare published projects with memory-only foreign sessions (2026-10-23, prepared)

The combined published/isolation harness now assigns disjoint guest-loopback ports
to two zod/nec pairs. Foreign-session refusal uses ephemeral in-memory handles;
cleanup preserves original cookies even on failure. Both pairs must stay live for
independent writes. All37 offline checks and appliance23-03 hash verification pass.
This prepares M037's published-duplicate gap without claiming runtime completion.
See diagnostics/2026-10-23-published-pairs-preparation.md. No production access.

## M040 — Fresh login selection reaches a still-failing backend (2026-10-23, current)

Trial23-02 selected the correct fresh container after two observations, then
recorded one failed code-access audit. This resolves M035's fixture-selection gap
but does not pass M031's code-retrieval runtime gate. The stage/cause is unknown;
4-second timeout is only a hypothesis. Original images and44 receipts are verified
and retained. The successor adds fixed-stage/outer-deadline-only audit diagnostics,
with all timeouts and identity checks unchanged; race/vet checks pass. A fresh
runtime diagnostic remains required. See diagnostics/2026-10-23-login-backend-trial02.md.

## M041 — Actual-ship anchor recovery requires all old members stopped first (2026-10-23, prepared)

The new separate anchor-recovery gate preserves old-container/namespace evidence,
requires public refusal after anchor restart, then stops every old member before
replacing either. Original piers/sessions and a queued subscription must recover,
followed by another peer write. All41 offline network checks and appliance23-05
hash verification pass. This prepares the actual-ship extension of M033, without
superseding its fixture-only qualification or claiming runner support. See
diagnostics/2026-10-23-anchor-preparation.md.

## M042 — Login code was discarded at the final identity deadline (2026-10-23, current)

Trial23-04's audit confirms `identity-after` with the outer deadline expired,
superseding M040's unconfirmed timeout hypothesis. The secret was correctly not
returned. Original disks/44 receipts are verified and retained. The source fix
allows12seconds for the verified read and15seconds for only its client/response;
ordinary RPCs remain5seconds and all checks/per-call limits remain. Race tests
include a slow real Unix HTTP response past5seconds, prompt caller cancellation,
no replay and redaction; vet passes. The real-runtime success gate remains open.
See diagnostics/2026-10-23-login-deadline.md.

## M043 — Real runner login survives same-pier replacement (2026-10-23, current)

Fresh VM23-06 passed both exact code selections, direct authenticated scries and
session revocation across a same-pier replacement container. Two successful access
audits, unchanged revision, preserved import tree, final Stop and clean poweroff
were independently verified; original disks and51 receipts remain retained. This
supersedes M042's runtime-fix-pending status and closes M031's basic runner gate.
Relocated admin ports remain source-tested only; shared-project runner integration
is separate. Ordinary client timeouts remain unchanged. See
diagnostics/2026-10-23-login-restart.md. No production access occurred.

## M044 — Exact container identity does not preserve its network namespace (2026-10-23, source-qualified)

Project assessment now binds complete reviewed ownership, revision/generation,
engine/resource contracts, exact publications and boot-bound namespace identity.
It retains old membership and requires recovery after an anchor namespace change;
missing resources never imply a clean stop. Race tests/vet pass for incomplete,
foreign and stale evidence. This implements part of M033's recovery contract,
without superseding fixture/runtime limits. It performs no engine calls and is
not persisted; runtime journaling still needs a schema fence and driver integration.
See diagnostics/2026-10-23-project-observation.md.

## M045 — Journal returned resource IDs before inspecting them (2026-10-23, source-qualified)

Schema24 now fences durable bridge/anchor preparation: planned → dispatched →
created with exact returned ID → observed. Losing an inspection result must not
lose the creation ID; losing the create reply remains unresolved dispatch.
Atomic mirrors, sequence/operation guards, eight restart boundaries and source
race/vet tests pass. The original schema23 writer reproduces populated ownership;
its reader refuses actual schema24 pending dispatch unchanged. This supersedes
M038's schema23-current status and M044's preparation-persistence gap only. No
engine driver, member launch or RPC/capability exists yet. See
diagnostics/2026-10-23-project-journal.md; earlier evidence and limits remain.

## M046 — Dispatch and inspection follow separate durable commits (2026-10-23, source-qualified)

The private preparation controller/SQLite worker now enforce intent-before-create,
returned-ID-before-inspection and engine checks around resource calls. Lost replies,
errors with IDs, cancellation and mismatches preserve uncertainty without replay or
inverse actions. Inert-engine race tests pass, including real SQLite readback inside
calls. The Unix engine probe retains an exact optional daemon ID; new project work
requires a matching ID, while historical report behavior stays compatible. This
supersedes M045's missing private-controller wiring only. No real Docker adapter,
server scheduling or member lifecycle is qualified. See
diagnostics/2026-10-23-project-dispatch.md. Schema22→24 original-reader checks pass.

## M047 — The pinned anchor image declares a data volume (2026-10-23, source finding)

Digest-verified OCI config `d6cc5107…b245` for the pinned Vere image declares
`/urbit` as both a volume and working directory, plus image-level ports80/tcp and
34343/udp. Reusing this image as a sleeping namespace anchor must account for the
volume explicitly; a stopped anchor is not evidence that all generated storage
is owned or cleaned up. Prefer an explicit bounded ephemeral mount for the anchor,
then inspect its exact mount contract in the private VM before integration.
Image EXPOSE entries alone are not host publications. Retained config/evidence:
`2026-10-23-anchor-image` under task qualification evidence. This adds a resource-
ownership requirement to M046; it does not supersede earlier transport passes or
claim runtime volume behavior/cleanup qualification. No Docker engine was accessed.

## M048 — Prepare only fresh owned bridge and stopped-anchor resources (2026-10-23, source-qualified)

The private Docker adapter now binds verified owner/daemon/image, exact returned
IDs and fixed resource settings to the journal controller. Fresh setup creates
metadata only and requires a locally installed pinned image. Inert-engine race
checks and vet pass for lost replies, changed ownership, unknown attachments and
mounts. A bounded `/urbit` tmpfs addresses M047's declared image volume in source;
actual engine behavior remains unqualified. This supersedes M046's missing-adapter
source status only. Server scheduling/fences, members and recovery are unfinished.
See diagnostics/2026-10-23-project-adapter.md. No production access occurred.

## M049 — Published duplicate projects retain independent state and sessions (2026-10-23, current)

VM23-03 passed114 direct published requests across two independent zod/nec pairs,
with five writes/17 observations per pair, same-pier subscription recovery and
four cross-project same-identity session401 refusals. Clean ship/anchor stops and
poweroff passed. Journald split the large final result; the original driver failure
is retained. Strict reconstruction equals the disk receipt, and all original
hashes/17 extracted receipts were verified. The bounded parser now has source tests.
This supersedes M039's runtime-pending status and closes M037's published duplicate
gap only. Actual-ship anchor recovery and runner integration remain. See
diagnostics/2026-10-23-published-project-isolation.md.

## M050 — Count queued project workers before admitting management updates (2026-10-23, source-qualified)

Private server admission now holds the runner mutex across receipt/worker creation,
counts queued work for updates and takes the shared resource gate before session
setup. It rechecks ownership and retained maintenance there. Inert race tests cover
queue cancellation, setup failure, replay, busy updates and successful release.
This supersedes M048's missing private server-fence wiring only; no public route or
startup scheduling exists. A guarded real-adapter VM test is compiled, skipped on
host, and being packaged. Actual-engine behavior and members remain separate gates.
See diagnostics/2026-10-23-project-fence.md. Production remains untouched.

## M051 — A late client failure must not erase a returned resource ID (2026-10-23, source-qualified)

The adapter now preserves an exact complete create ID even with client failure or
cancellation, allowing the controller to journal it and stop. Ordinary command
errors still discard output; missing/malformed IDs remain unresolved. Source race
and redaction regressions/vet pass. Initial anchor validation now distinguishes
never-started `created` resources from stopped former processes and refuses unknown
tmpfs options. This refines M048/M050 without runtime qualification. Prepared
appliance23-07 predates these checks; keep its frozen identity and replay its later
receipt against current pure validators before claiming compatibility. See
diagnostics/2026-10-23-project-refinement.md. No production engine was accessed.

## M052 — Restarted forwarding may return no HTTP response without connect refusal (2026-10-23, failed trial/source fix)

Actual-ship VM23-05 failed at its first post-restart endpoint assertion after
proving stopped-anchor refusals and changed namespace with old members retained.
The exact failing curl outcome was not recorded; do not retroactively label it52.
The verified prior endpoint20 fixture did return52/status000 in this situation.
The successor probe now records bounded facts and requires a recognized transport
failure, status000 and no body. All43 offline tests pass. Trial05's18 receipts and
original disks remain; ships/poweroff stopped cleanly but channel/session cleanup
was incomplete. This supersedes M041's unexecuted status, not its unpassed recovery
gate. See diagnostics/2026-10-23-anchor-trial05.md. A fresh retry is needed.

## M053 — Real preparation preserves journal ownership without starting ships (2026-10-23, current)

VM23-07 passed real bridge/stopped-anchor creation through the private SQLite
worker/controller/adapter, exact-ID inspections, duplicate refusal and unchanged
receipt/journal after reopen. No instance/pier or anchor process was started.
Explicit `/urbit` tmpfs configuration created no persistent volume. The17 receipts,
original disks and extracted database were independently verified; current pure
validators also accept the frozen runtime inspections. This closes M048's basic
real-adapter gate and M047's creation-stage volume concern, not Start/mount runtime,
public RPC, real server concurrency, members or recovery. M051's error-path tests
remain source-only. See diagnostics/2026-10-23-project-preparation-runtime.md.

## M054 — Anchor Start needs its own receipt and complete namespace inventory (2026-10-23, source-qualified)

The pure initial-Start controller now requires completed preparation, distinct
operation identity, intent-before-Start and fresh post-ack namespace/publication
proof. It never treats anchor completion as member readiness or retries uncertainty.
The pure inventory resolver includes indirect container joins that bridge endpoint
lists omit, refusing missing/ambiguous/cyclic references. Race tests and vet pass.
This narrows M053's missing Start-model gap only; persistence and actual Start
adapter remain unfinished. See diagnostics/2026-10-23-anchor-start-model.md.

## M055 — Persist initial anchor Start separately from creation (2026-10-23, source-qualified)

Schema25 now retains a distinct Start journal and operation mirror, preserving
completed preparation. Private workers commit dispatch/ack/namespace in order;
reopen interrupts unfinished work without replay. Inert race tests cover every
boundary, corruption, atomic rollback, competing claims and lost replies. The
original schema24 snapshot reproduces populated preparation and refuses actual
schema25 dispatched Start unchanged. This supersedes M054's persistence gap and
M045's schema24-current status only. Actual Start adapter/server scheduling,
members, recovery and release qualification remain. See
diagnostics/2026-10-23-anchor-start-journal.md.

## M056 — Recover every old member after the anchor namespace changes (2026-10-23, current)

VM23-08 independently passed actual-ship published anchor recovery:65 requests,
six durable writes/19 observations/nine facts; unchanged piers and original sessions
and subscription recovered after all old members stopped before replacements.
The restarted anchor retained its container ID but changed namespace; old members
remained in the old namespace. New empty publications returned52/status000 until
recovery. All channels/sessions and processes cleaned up; clean poweroff1349.52s.
Sixteen receipts and original disks remain. This supersedes M052's unpassed actual
recovery gate, not its failed outcome or M033's limits. Runner member recovery is
still unimplemented. See diagnostics/2026-10-23-anchor-state-recovery.md.

## M057 — Inspect all namespace joins before initial anchor Start (2026-10-23, source-qualified)

The private Start adapter now verifies original metadata/engine/image contracts,
complete bounded container joins, stable before/after observations and boot-bound
namespace/publication evidence. The server queues it behind common resource and
update fences; setup failure retains planned intent. Inert race tests and vet pass.
This supersedes M055's missing adapter/scheduling source status only. Appliance23-09
is verified and running its separate real anchor-only test; no runtime pass yet.
Member lifecycle/public routes remain. See diagnostics/2026-10-23-anchor-start-adapter.md.

## M058 — Qualify helper paths against the pinned image (2026-10-23, failed trial/source fix)

Actual anchor-only trial09 retained an acknowledged Start as interrupted because
`/usr/bin/stat` is absent. The fresh anchor stopped cleanly and VM powered off in
229.64s;19 receipts, SQLite and disks remain verified. Digest-verified OCI layers
place BusyBox stat at `/bin/stat`; its short-option probe passes in private
Bubblewrap. The source is corrected and race/vet checks pass. This supersedes
M057's runtime-pending status with a failed result, not a Start pass. The running
mount/publication contract separately replays successfully. Exact two-field Docker
OOM normalization is documented. See diagnostics/2026-10-23-anchor-start-trial09.md.

## M059 — Shared-network members need separate launch and cleanup ownership (2026-10-23, source-qualified)

Standalone managed execution owns a per-instance bridge and assumes internal8080;
pointing it at a shared anchor would violate peer ownership. The first pure member
invocation builder now uses each reviewed internal port and `<ship>` pier leaf,
separates fresh boot from resume flags, and passes focused race tests. This is a
new member-integration slice, not runtime authority or a modification of standalone
ships. Storage/creation/readiness/cleanup remain. See
diagnostics/2026-10-23-member-command.md; M056's actual recovery ordering still applies.

## M060 — Private runner initial anchor Start passes on the pinned image (2026-10-23, current)

Fresh VM23-10 passed real queued Start with SQLite dispatch/ack/namespace ordering,
exact loopback publications and empty complete namespace inventory. Reopen/replay
preserved the original creation receipt and completed Start. No member/pier ran;
the anchor stopped143 without OOM and poweroff took230.38s. Seventeen receipts,
database and original disks remain independently verified. Full managed race tests
passed77.457s. This supersedes M058's fresh-retry requirement and M057's unqualified
initial Start path, not trial09's failed evidence. Member lifecycle/recovery and
public interfaces remain. See diagnostics/2026-10-23-anchor-start-runtime.md.

## M061 — Bind a member container to its exclusive parent and namespace (2026-10-23, source-qualified)

The private contract binds runtime/member/operation/generation, completed anchor
namespace and recorded mount identity into a creation digest. Temporary-filesystem
checks retain partial/replaced/locked piers; inspection tests reject peer mounts,
implicit volumes and independent networking. Resume has no boot flags/pill mount.
Race regressions and vet pass; the initial incomplete synthetic checkpoint fixture
is recorded. This extends M059's command-only slice without engine dispatch or a
schema change. Durable member storage/claims, fresh inventories and lifecycle still
remain. See diagnostics/2026-10-23-member-contract.md.

## M062 — Journal member mkdir separately and reserve its exclusive parent (2026-10-23, source-qualified)

Schema26 retains accepted member/path/runtime claims, dispatch, created directory
identity and observed completion. Late failure preserves known identity; reopen
interrupts without replay/adoption. Legacy storage moves/imports cannot overlap.
Temporary-filesystem and race tests pass; full managed race80.555s. The original
schema25 writer reproduces completed Start state and refuses real schema26 member
dispatch unchanged. New snapshots exclude redundant nested archives while keeping
their hashes and originals. This supersedes M055's schema25-current status and
M061's missing storage-claim slice, not M060's frozen runtime pass. Server scheduling,
actual owner/VM integration and member lifecycle remain. See
diagnostics/2026-10-23-member-storage.md; initial fixture failures remain recorded.

## M063 — Queue member storage behind the same resource/update fences (2026-10-23, source-qualified)

Private queue tests pass cancellation/setup/maintenance failure, actor replay and
busy-update refusal. Setup cannot bypass the shared gate. The guarded VM case uses
the real filesystem driver for two empty member parents, with SQLite readback at
dispatch/inspection and reopen checks. All host guards skip,13 offline tests and
project race/vet checks pass. Appliance23-11 verifies61 source hashes and its embedded
test; the no-NIC VM is running, not yet qualified. This supersedes M062's missing
server-scheduling source gap only. No public route or ship launch exists. See
diagnostics/2026-10-23-member-storage-queue.md.

## M064 — Real queued storage preserves two empty member parents (2026-10-23, current)

Fresh VM23-11 passed real schema26 queue/filesystem preparation, SQLite ordering,
replay refusal and unchanged journals after reopen for both runtime-bound parents.
Offline ext4 inspection independently matches inode/birth,1000:1000 ownership,
0700 permissions and empty contents. No member/pier ran; only the stopped anchor's
container directory remains. All17 receipts and original disks are verified;
clean poweroff217.13s. This supersedes M063's pending VM and M062's unqualified
owner/runtime storage gate only. Container lifecycle/readiness/recovery remain;
new anchor namespaces require new evidence, preserving the original Start receipt.
See diagnostics/2026-10-23-member-storage-runtime.md.

## M065 — Observe actual member namespaces without adopting or rebinding (2026-10-23, source-qualified)

The read-only private adapter verifies exact journaled member contracts and the
complete bounded namespace inventory, bracketing member reads with unchanged
engine/anchor/bridge evidence. Unknown joins and in-flight changes refuse; a
coherent old member namespace remains explicit evidence for recovery. Created
containers have no running namespace. Twenty-two inert scenarios, focused race
regressions and vet pass. This supersedes M061's missing namespace-observation
slice only; it does not qualify dispatch, storage-use checks or readiness. No
schema/receipt change or runtime access. See diagnostics/2026-10-23-member-observation.md.

## M066 — Saved mount sources are a conflict check, not historical mount proof (2026-10-23, source-qualified)

The private bounded inventory rejects current object/path overlaps, aliases,
unresolved volume sources and changing/incomplete observations. Only an exact,
fully verified never-started member gets its own-mount exception. Twenty-four
inert scenarios, ancestry/replacement tests, race regressions and vet pass.
This adds M065's separate mount-conflict slice; it does not supersede lifecycle
ownership, locks or kernel-mount uncertainty. A saved source path can outlive the
object originally mounted. No schema/runtime change. See
diagnostics/2026-10-23-member-mounts.md. Durable member launch remains next.

## M067 — Journal each initial member execution effect before dispatch (2026-10-23, source-qualified)

The pure launch model binds original storage/anchor receipts and exact peers,
orders workspace/Create/Start intent and returned evidence, and retains known
identities after late failure. Complete fresh observations require the original
namespace and peer contracts. Twenty-four controller outcomes, invalid-binding
tests, race regressions and vet pass. This adds the controller slice after M065/
M066; persistence and actual dispatch remain. `running` means container execution,
not initialized storage or Urbit readiness. No schema/runtime change. See
diagnostics/2026-10-23-member-launch-model.md.

## M068 — Persist initial member execution without rewriting earlier receipts (2026-10-23, source-qualified)

Schema27 journals accepted launch, fixed binding and workspace/Create/Start phases
with atomic operation mirrors. Reopen interrupts without replay; serial project
admission preserves exact peer ownership. Nine boundaries, competing claims,
rollback/corruption and SQLite-readback worker tests pass. Full managed race90.780s.
The original schema26 snapshot reproduces completed anchor/two-parent storage and
refuses real schema27 launch dispatch unchanged. This supersedes M062's schema26-
current status and M067's missing persistence slice only. Concrete adapter/queue,
VM runtime and ship readiness remain; running-container success is not readiness.
No installed state changed. See diagnostics/2026-10-23-member-launch-store.md.

## M069 — Initial member dispatch uses fresh private artifacts and shared fences (2026-10-23, source-qualified)

The concrete adapter copies an already staged pinned pill into a new owned
workspace, then binds Create/Start to fresh namespace, parent, artifact and mount-
conflict checks. Known identities survive late failure; partial piers refuse boot.
The private queue holds the common work/update gates and preserves setup failures.
Eleven inert engine/filesystem scenarios, queue tests, race regressions and vet
pass. This supersedes M068's missing adapter/queue source slice only. No downloads,
public routes, schema change or real runtime occurred. Private-VM and readiness
gates remain. See diagnostics/2026-10-23-member-launch-adapter.md.

## M070 — Real member launch requires guarded queue and cleanup evidence (2026-10-23, preparation-qualified)

The new private-VM fixture launches two members through the actual queue, observes
committed SQLite phases, preserves replay/reopen receipts and requires exact-ID
ownership checks before member-first/anchor-last cleanup. Pill staging is explicit.
Ordinary guards, focused race regressions, vet, 96 source hashes and the embedded
appliance binary pass. This supersedes M069's missing VM fixture only; it does not
claim real execution or durable readiness/Stop/recovery. Sources and preparation
proof are retained. See diagnostics/2026-10-23-member-launch-vm-preparation.md.

## M071 — Readiness must bind current identity to stable initialized storage (2026-10-23, source-qualified)

A pure read-only model now reconstructs the full serial launch set, brackets a
credential-free public ship-identity check with unchanged complete runtime and
pier/`.urb` observations, and returns only complete fresh evidence. Its historical
receipt cannot be reused as current authority. Forty-five inert cases, race
regressions and vet pass. This adds the readiness model missing in M069/M070;
concrete collection, persistence and real readiness qualification remain. It does
not supersede any runtime evidence. See diagnostics/2026-10-23-member-readiness-model.md.

## M072 — Trial12 preserves stale dispatch and failed early shutdown (2026-10-23, failed real trial)

The first queued member (nec) reached a committed running-container receipt; the
second (zod) was refused at create-dispatched because final preflight expired.
No second container was created. First-member cleanup exhausted 300 seconds and
exited 137 without OOM; the anchor and VM stopped cleanly. Independent SQLite,
exact-container inventory and evidence hashes confirm the failure, and all
original disks remain retained. Repeated hashing inside the freshness window
needs a stable verified-file check; retain the 30-second bound. The fixture also
omitted the previously passing --init/zod-first pattern. Shutdown cause is not
isolated. This supersedes M070's pending trial status only, not any earlier pass.
See diagnostics/2026-10-23-member-launch-trial12.md.

## M073 — Hash immutable artifacts before the final runtime freshness window (2026-10-23, source/preparation-qualified)

Workspace/preflight still hash the pinned pill, bracketing full file metadata.
Final Create/Start check the identical in-memory verified snapshot without another
full hash; the 30-second runtime/preflight bound is unchanged. Thirteen artifact
cases and concrete post-observation tampering cases pass with race regressions and
vet. The member contract now requires --init; the fresh VM fixture boots zod first,
matching earlier qualified cases. This supersedes M061's no-init contract and
M069's repeated-dispatch-hash implementation only, while preserving their older
source evidence and all failed M072 disks. Appliance13 was independently verified
(100 sources); its runtime remains pending. Shutdown causality is still unisolated.
See diagnostics/2026-10-23-member-launch-refinement.md.

## M074 — Readiness collection performs only bound observations (2026-10-23, source-qualified)

The concrete collector reconstructs complete original member contracts, checks
parent and pier/`.urb` identities, and gates credential-free host identity reads
on fresh complete running-project evidence. Seventeen injected-engine and fresh
filesystem cases plus race regressions/vet pass. No mutation or download command
is available through the collector. This supersedes M071's missing concrete
adapter source slice only; durable storage/queue and real readiness qualification
remain. VM13's earlier frozen binary cannot qualify this collector. See
diagnostics/2026-10-23-member-readiness-adapter.md.

## M075 — Trial13 reached second Create but still refused stale Start (2026-10-23, failed real trial)

The refined immutable-artifact dispatch let nec reach Create after zod launched.
Start then refused stale preflight, leaving a retained exact ID, start-dispatched
journal and independently verified never-started container. Zod's early cleanup
again exited 137 after 300 seconds without OOM, despite --init/zod-first. The
anchor and VM shut down cleanly; all original disks and failed receipts are
preserved. This supersedes M073's pending runtime status and the sufficiency of
its cleanup candidates, not its passed source tests or M072's retained failure.
Batch repeated exact-container reads and expose freshness ages next. No clean
pair or readiness pass is claimed. See diagnostics/2026-10-23-member-launch-trial13.md.

## M076 — Batch exact-container reads without weakening freshness (2026-10-23, source/preparation-qualified)

The observer batches full inspections of recorded IDs while retaining all member
contracts, complete inventories and repeated namespace checks. Malformed batches
and invalid selections refuse; reordered valid responses pass. Dispatch errors
report bounded freshness ages. Focused race suites and vet pass; appliance14's
102 source files and embedded test were independently verified. This supersedes
M075's pending batching source work only. Trial14 is pending, both original failed
trials remain retained, and early-boot cleanup is unresolved. See
diagnostics/2026-10-23-member-observation-batch.md.

## M077 — Retain every readiness attempt without replaying launch (2026-10-23, source-qualified)

Schema28 records separate planned/observing/observed attempts and mirrors their
complete original launch binding. Restart interrupts unfinished observations;
exact actor/request replay returns the original receipt, while a new read-only
attempt preserves the old one. Completed evidence is historical, never current
runtime authority. Twenty-four focused cases, full managed race tests and vet
pass. Frozen original schema27 fixtures reproduce exactly and its reader refuses
real schema28 state unchanged. This supersedes M074's missing persistence slice
only; private scheduling and real readiness remain. VM14 stays schema27. See
diagnostics/2026-10-23-member-readiness-store.md.

## M078 — Schedule readiness behind the existing runner gates (2026-10-23, source-qualified)

The private queue shares work/update admission, validates complete original launch
bindings, and retains interrupted setup/cancellation failures. Five queue cases,
combined project race suites and vet pass. The guarded VM fixture now checks real
queued readiness, replay and reopened receipt equality; ordinary and explicitly
enabled host guards refuse runtime access. This supersedes M077's missing private
queue and readiness fixture only. No public route, startup task or real readiness
pass is claimed; VM14 stays the earlier schema27 binary. See
diagnostics/2026-10-23-member-readiness-queue.md.

## M079 — Trial14 passed dispatch but failed cold-boot/cleanup gates (2026-10-23, failed real trial)

Both members reached committed running receipts with unchanged namespaces and no
stale-dispatch recurrence. The final HTTP wait expired; nec cleanup exited137
without OOM, while zod, anchor and VM stopped cleanly. Independent SQLite/disk
checks and all original evidence are retained. Earlier VM08 needed about405 and
585 seconds for serial cold boots; trial14's480-second final wait and900-second
whole-operation budget were not a suitable baseline. This supersedes M076's
pending runtime status and M075's outstanding stale-dispatch recurrence only.
There is no complete readiness/cleanup pass or proven shutdown cause. Use serial
identity warmup with sufficient bounded time, keeping ownership freshness intact.
See diagnostics/2026-10-23-member-launch-trial14.md.

## M080 — Budget cold boot separately from ownership freshness (2026-10-23, source/preparation-qualified)

The next fixture uses serial exact-identity warmup with 900 seconds per ship and
2400 seconds for setup/launch/readiness, followed by separately bounded cleanup.
Five HTTP fixture cases plus readiness regressions/vet pass. Runtime ownership
and preflight freshness remain 30 seconds; CPU, memory and network isolation are
unchanged. Appliance15's frozen sources and embedded binary are verified. This
supersedes M079's inadequate fixture ordering/time budget and the final login-page
wait from M070, not its failed runtime evidence. Real schema28 readiness remains
pending. See diagnostics/2026-10-23-member-readiness-preparation.md.

## M081 — Graceful Stop preserves intent, exit evidence and peer state (2026-10-23, source-qualified)

The initial Stop model requires fresh exact running ownership and unchanged
initialized storage, commits intent before one graceful signal, and retains
uncertainty without automatic retry, force or removal. A completed observation
must preserve process start identity, pier objects and every peer/project field;
nonzero/OOM exits remain recorded failures. Inert interruption, tampering, peer
and cancellation cases plus project race regressions/vet pass. This adds the Stop
model missing in M067/M078; persistence, concrete dispatch and runtime qualification
remain. It does not supersede any real shutdown failure. VM15 lacks this model.
See diagnostics/2026-10-23-member-stop-model.md.

## M082 — Persist Stop once per exact container and preserve uncertain outcomes (2026-10-23, source-qualified)

Schema29 journals accepted bindings, dispatch, acknowledgement and exit separately.
Only a clean acknowledged worker result finalizes success; unclean exits remain
failed, and lost/canceled/late outcomes remain interrupted with evidence intact.
Replay cannot re-signal, and unresolved project Stops block another Stop. Restart,
concurrency, tampering and worker tests plus full managed race/vet pass. Original
schema28 fixtures reproduce exactly and its reader refuses actual schema29 state
unchanged. This supersedes M081's missing persistence only. Concrete Stop, queue,
recovery and runtime gates remain; VM15 is frozen schema28. See
diagnostics/2026-10-23-member-stop-store.md.

## M083 — Real queued launch and durable readiness pass with serial cold boot (2026-10-23, runtime-qualified)

Private VM15 passed in1231.94 seconds: both original member launches, exact public
identities, queued complete readiness proofs, unchanged replay/reopen receipts,
and member exit0/anchor/guest cleanup. Independent database, filesystem and artifact
checks pass; all original disks are retained. Measured serial warmup was340.14 and
508.19 seconds, with runtime freshness still30 seconds. This supersedes M080's
pending runtime gate and M078's missing real readiness evidence, and completes the
initial-launch/fixture-cleanup gate absent in M072/M075/M079. Those failed originals
and their unproven root causes remain recorded. This does not qualify schema29
Stop, resume/recovery or public routes. See diagnostics/2026-10-23-member-readiness-runtime.md.

## M084 — Bind graceful Stop to exact live and exited processes (2026-10-23, source/preparation-qualified)

The observer retains bracketed full process metadata; exited containers require
an explicit recorded start and unchanged original contract. The concrete Stop
adapter rechecks fresh ownership/storage, sends one explicit TERM, and waits
read-only without force/removal. Completed peer exits remain exact, and the private
queue shares update/maintenance gates with durable phase-before-effect callbacks.
Thirty adapter cases, six queue cases, affected race suites and vet pass. Guarded
VM Stop/replay/reopen coverage and appliance16 are prepared and verified. This
supersedes M082's missing concrete adapter/queue source slice only. Real durable
Stop and recovery remain pending; M083's readiness result and all earlier failed
trials remain unchanged. See diagnostics/2026-10-23-member-stop-preparation.md.

## M085 — Observe an uncertain Stop without inventing its acknowledgement (2026-10-23, source-qualified)

A separate read-only model/adapter records fresh exact-process exit evidence while
preserving the original dispatched Stop and its uncertainty. Clean/nonzero/OOM
outcomes remain observations; no retry, re-signal, removal or resume follows.
Known exit metadata cannot change. Twenty-two model and ten concrete inert cases,
race regressions and vet pass. This fills the read-only recovery-model slice left
open in M082/M084; persistence, scheduling and real recovery remain unimplemented.
It supersedes no runtime result. VM16 predates this code. See
diagnostics/2026-10-23-member-stop-exit-source.md.

## M086 — Persist recovery observations without rewriting Stop (2026-10-23, source-qualified)

Schema30 retains separate read-only attempts and atomic receipt mirrors. Restart
interrupts unfinished observation; replay and new attempts preserve prior evidence.
Fresh exact-process completion can record clean or unclean exit without changing
the original uncertain Stop or its admission fence. Focused tests, full managed
race tests and vet pass. Original schema29 fixtures reproduce exactly and the old
reader refuses real schema30 state unchanged. This supersedes M085's missing
persistence slice only; queue, real recovery and resume remain. VM16 stays frozen
schema29. See diagnostics/2026-10-23-member-stop-exit-store.md.

## M087 — Real queued graceful Stop preserves both ships and receipts (2026-10-23, runtime-qualified)

Private VM16 passed in1293.24 seconds: nec then zod each received one committed
graceful Stop, exited0 without OOM, and retained exact process/pier/peer evidence.
Replay, repeat-dispatch refusal, reopen and clean anchor/guest cleanup passed.
Independent disk/SQLite/artifact verification passed; every original is retained.
This supersedes M084's pending real initial Stop gate, not M085/M086's recovery
limits. VM16 is schema29 and cannot qualify lost-reply recovery, resume or public
integration. See diagnostics/2026-10-23-member-stop-runtime.md.

## M088 — Queue read-only recovery with original Stop uncertainty intact (2026-10-23, source/preparation-qualified)

The private queue shares work/update/maintenance gates and carries exact completed
peer exits. Seven queue cases, affected race suites and vet pass. The guarded
fixture deliberately discards the last member's actual Stop reply, then observes
its exit separately while preserving interrupted dispatch and replay/reopen.
Host guards and appliance17's127-source embedded binary verification pass. This
supersedes M086's missing queue and M085's missing runtime fixture only. Real
recovery remains pending; peer lifecycle changes, resume and public access remain
unsupported. VM16's earlier pass is unchanged. See
diagnostics/2026-10-23-member-stop-exit-preparation.md.

## M089 — Retire only an exact cleanly stopped container before replacement (2026-10-23, source-qualified)

A separate explicit intent commits removal before one exact-ID command, retains
acknowledgement and complete absence separately, and preserves piers, peers and
all old receipts. No force/volume removal, retry or replacement is implied.
Thirty-four model and nineteen injected-adapter cases, race suites and vet pass;
temporary state files retain inode/bytes. Transport cancellation discards its
reply, so that removal remains uncertain. This adds the retirement source slice
missing from M087/M088's resume work; persistence, queue and real retirement remain.
No earlier runtime result is superseded. VM17 predates this code. See
diagnostics/2026-10-23-member-retirement-source.md.
